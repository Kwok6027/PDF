NOTE: To get past file-type filters, the four scripts in this zip are shipped with a
".txt" extension (e.g. run_ghidra_decompile.py.txt). After unzipping, remove the trailing
".txt" from each filename so they end in ".py" again before running them.

----------------------------------------------------------------------

# Automated Ghidra decompile pipeline (Python)

Turns a DLL/EXE into decompiled C with one command, fully automated (no clicking,
no per-field decisions).

## What you need (once)
- **Ghidra** installed (download + unzip) and a **JDK 17 or 21**. These are NOT
  pip-installable — there is no way around installing them.
- That's it. The scripts here need **no pip packages** (Tkinter ships with standard
  Python; if it's missing the launcher falls back to console prompts).

## Files (keep all four in the same folder)
- `run_ghidra_decompile.py`  - the launcher. Run THIS with your normal Python.
- `ghidra_pre_options.py`    - Ghidra Jython pre-script (sets analyzer options).
- `ghidra_post_export.py`    - Ghidra Jython post-script (RTTI recovery + decompile + DAT_ dump).
- `merge_dat_into_c.py`      - folds the DAT_ values back into the .c (the launcher runs it for you).

## How to run
```
python run_ghidra_decompile.py
```
It pops up three boxes:
1. choose the DLL/EXE,
2. choose your Ghidra install folder (only if it can't auto-detect it; you can also
   set the env var GHIDRA_INSTALL_DIR to skip this),
3. choose the output folder (Cancel = the launcher's own folder).

Then it runs Ghidra headless and, when finished, writes into the output folder:
- `<name>.decompiled.c`             - every function decompiled to C
- `<name>.dat_constants.csv`        - every DAT_ constant: address, read-only flag,
                                      raw qword, little-endian double, and any typed value
- `<name>.decompiled.with_values.c` - the .c with the DAT_ values folded in (READ THIS ONE):
                                      a header table of all constants, plus a /* DAT: ... */
                                      note on every line that uses one (value, or <runtime>).

To also substitute read-only doubles in place (DAT_x -> (0.5)) for the most readable
formulas, re-run the merge yourself with --inline:
```
python merge_dat_into_c.py <name>.decompiled.c <name>.dat_constants.csv out.c --inline
```
(NOTE: if your DLL's image base is not 0x180000000, edit IMAGE_BASE at the top of
merge_dat_into_c.py so pointer-vs-double classification stays correct.)

## What it does automatically
1. Imports + analyzes the binary with Decompiler Parameter ID (=__thiscall), the
   Microsoft demangler, RTTI analysis, and switch analysis enabled.
2. Runs RTTI class recovery (RecoverClassesFromRTTIScript) to rebuild C++ classes/vtables.
3. Best-effort automatic structure fill-out from how each function uses its pointer
   parameters (version-sensitive; it never aborts the run if unavailable).
4. Decompiles every function into the single .c file.
5. Dumps all DAT_ constant values (non-destructive - it reads bytes, it does not retype).

## Honest limits
- Output is offset-correct and type-inferred but **auto-named** (fields like
  `field_0x30`, locals like `lVar1`). Names don't affect the math; offsets/types are
  derived from the machine code.
- It will NOT undo compiler optimizations (FMA, vectorization, divide-by-constant).
- Only READ-ONLY (.rdata) DAT_ entries have a real static value; writable globals
  read as runtime state (the `read_only` column tells you which is which).
- The structure fill-out step (3) uses an API that changes between Ghidra versions.
  If your console log shows it was skipped, the rest still works; tell me your Ghidra
  version and I'll wire that step to match it.

These scripts were written defensively but could not be test-run against a live
Ghidra here, so if anything errors, copy the console output and I'll fix it.
```
```
