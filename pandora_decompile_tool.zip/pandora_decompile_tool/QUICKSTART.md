# Pandora decompile tool — quickstart

## What's in this folder

| File | What it is |
|---|---|
| `GhidraPostExport.java` | **The fixed Ghidra script.** Recovers ALL functions (incl. internal C++ methods like `HaganBBF_asymptoticFormula::getVol` that auto-analysis misses), then decompiles every one. |
| `gd.py` | The launcher you run. Drives Ghidra headless, then runs the two Python steps. |
| `extract_rdata_tables.py` | Pulls the bulk `.rdata` data tables out of the binary. |
| `merge_dat_into_c.py` | Folds constants + full data tables into one self-contained `.c`. |

These four files must sit **in the same folder**. (`GhidraPostExport.java` replaces the old copy you had.)

## Prerequisites (one-time)

1. **Ghidra** installed (the folder that contains `support/analyzeHeadless`) + a **JDK** (Ghidra needs Java).
2. `pip install pefile`  (and optionally `pip install numpy`). If `pefile` is missing, the decompile still runs; only the `.rdata` table step is skipped.

## Run it

```
python gd.py
```

It pops up (or, with no GUI, asks on the console) for:
1. the **DLL** to decompile,
2. your **Ghidra install folder** (only if it can't auto-detect it),
3. the **output folder** (Cancel = this script's folder).

A single progress bar runs 0→100% (analyze → extract → merge). Full Ghidra output goes to `<name>.ghidra.log` if you need it (`--verbose` shows it live).

## The one file to send me

When it finishes, send me only:

```
<name>.decompiled.with_values.inlined.c
```

That file is self-contained: every function (including the recovered ones), scalar constants inlined into the formulas, and the full referenced `.rdata` tables embedded as C arrays. You can ignore the `.csv`, the `rdata_tables/` folder, the `.bin`, the `.npy`, and the logs.

**Send the actual `.c` file — do not screenshot it.** (The earlier garbled constants were OCR damage from screenshots; the raw file is exact.)

## 5-second check before sending (optional)

In the output folder:

```
grep -c "getVol"  <name>.decompiled.c
grep -n "DATA TABLES"  <name>.decompiled.with_values.inlined.c
```

The first should be non-trivial and include a **defined** function body (not just calls); the second should find the embedded-tables block. If a function comes back marked `-- DECOMPILE FAILED`, tell me which one.

## Which DLLs to run (in order)

1. **`PandoraPricer.dll`** and **`PandoraFlowPricer.dll`** — one of these applies `epsilonPut`/`skewShift`/`conservativeEpsilons` and runs the callable rollback (the step that turns fair value into the system mark). Both are small. **Top priority.**
2. **`PandoraAsymptoticFormula.dll`** — `HaganBBF_asymptoticFormula::getVol`, the SABR smile.
3. **`PandoraMMMDynamics.dll`**, **`PandoraMarketVolatility.dll`** — MMM model/calibration and the vol surface.
4. **`PandoraPDESolvers.dll`**, **`PandoraMUBS.dll`** — PDE engine, basket.

**Skip** `PandoraMarketCurve.dll` and `PandoraCurveConstruction.dll` — they only *build* the SOFR curve, which is provided as market data. They're large/code-dense and not needed.

## Speed, and diagnosing a slow run

Decompile time scales with the **number of functions**, not file size. Small DLLs (most of the list) finish in minutes. A code-dense DLL (e.g. the 11 MB curve builder) can have tens of thousands of functions and take hours — which is why you skip it.

This version prints timestamped phase markers, so you can see it's progressing rather than hung. With `--verbose` (or in `<name>.ghidra.log`) you'll see lines like:

```
[post] +12s  recovered 1840 additional functions
[post] +30s  re-analysis of recovered functions done
[post] +45s  exporting full C
[post]  decompiled 2500/8100 functions...
```

If those keep advancing, it's working. If one line is frozen for a long time with no CPU use, send me the log.

### Targeted mode (for a big DLL you *do* need)

To pull just one class instead of the whole DLL:

```
python gd.py --filter HaganBBF
```

Only functions whose name contains the filter get decompiled (recovery still runs so the function exists). `--filter epsilonPut`, `--filter getVol`, `--filter Callable`, etc. This turns a multi-hour full export into a minutes-long targeted one.

## If a step errors

`gd.py` prints the path to the relevant log and stops. Send me `<name>.ghidra.log` (or `.merge.log` / `.rdata_extract.log`) and I'll fix the script.
