# Pandora decompile tool — quickstart

## What's in this folder

| File | What it is |
|---|---|
| `GhidraPostExport.java` | **The fixed Ghidra script.** Recovers ALL functions (incl. internal C++ methods like `HaganBBF_asymptoticFormula::getVol` that auto-analysis misses), then decompiles every one. |
| `gd.py` | The launcher you run. Drives Ghidra headless, then runs the two Python steps. |
| `extract_rdata_tables.py` | Pulls the bulk `.rdata` data tables out of the binary. |
| `merge_dat_into_c.py` | Folds constants + full data tables into one self-contained `.c`. |

These four files must sit **in the same folder**. (`GhidraPostExport.java` replaces the old copy you had.)

## Prerequisites (one-time)

1. **Ghidra** installed (the folder that contains `support/analyzeHeadless`) + a **JDK** (Ghidra needs Java).
2. `pip install pefile`  (and optionally `pip install numpy`). If `pefile` is missing, the decompile still runs; only the `.rdata` table step is skipped.

## Run it

```
python gd.py
```

It pops up (or, with no GUI, asks on the console) for:
1. the **DLL** to decompile,
2. your **Ghidra install folder** (only if it can't auto-detect it),
3. the **output folder** (Cancel = this script's folder).

A single progress bar runs 0→100% (analyze → extract → merge). Full Ghidra output goes to `<name>.ghidra.log` if you need it (`--verbose` shows it live).

## The one file to send me

When it finishes, send me only:

```
<name>.decompiled.with_values.inlined.c
```

That file is self-contained: every function (including the recovered ones), scalar constants inlined into the formulas, and the full referenced `.rdata` tables embedded as C arrays. You can ignore the `.csv`, the `rdata_tables/` folder, the `.bin`, the `.npy`, and the logs.

**Send the actual `.c` file — do not screenshot it.** (The earlier garbled constants were OCR damage from screenshots; the raw file is exact.)

## 5-second check before sending (optional)

In the output folder:

```
grep -c "getVol"  <name>.decompiled.c
grep -n "DATA TABLES"  <name>.decompiled.with_values.inlined.c
```

The first should be non-trivial and include a **defined** function body (not just calls); the second should find the embedded-tables block. If a function comes back marked `-- DECOMPILE FAILED`, tell me which one.

## Which DLLs to run (in order)

1. **`PandoraAsymptoticFormula.dll`** — gives `HaganBBF_asymptoticFormula::getVol`, the SABR smile (the keystone formula).
2. **The pricing / product DLL that consumes `MMMProductDetails`** — this is where `epsilonPut` / `skewShift` / `conservativeEpsilons` are *applied* (the step that turns fair value into the system mark). It is **not** in the eight files you've sent so far. Find it as the DLL that imports from both `PandoraModelParams.dll` and `PandoraMMMDynamics.dll` and contains the callable/Bermudan rollback — likely named `PandoraPricer.dll`, `PandoraExoticPricer.dll`, or `PandoraProduct.dll`.
3. (Optional) re-run on `PandoraMarketVolatility.dll` and `PandoraMMMDynamics.dll` so I have the clean, complete vol-surface and model/calibration code too.

## If a step errors

`gd.py` prints the path to the relevant log and stops. Send me `<name>.ghidra.log` (or `.merge.log` / `.rdata_extract.log`) and I'll fix the script.
