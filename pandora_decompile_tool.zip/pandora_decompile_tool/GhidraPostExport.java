// GhidraPostExport.java  -- drop-in replacement for the pipeline's post-script.
//
// WHY THIS VERSION EXISTS
// -----------------------
// The previous behaviour ("decompile every function") only ever saw the functions
// Ghidra's auto-analysis had *identified*. Internal C++ methods that are reached only
// through a vtable slot or an intra-DLL call -- e.g. HaganBBF_asymptoticFormula::getVol,
// the SABR smile body -- are frequently never turned into functions, so they silently
// never make it into the .c.  This version first RECOVERS those functions (call/branch
// targets, vtable function pointers in .rdata, and undefined executable code), re-runs
// analysis so the decompiler has prototypes/types for them, and only then decompiles
// EVERY function in the program -- exported or not.
//
// OUTPUT (unchanged contract, so gd.py / merge_dat_into_c.py / extract_rdata_tables.py
// keep working):
//   <program>.decompiled.c          one block per function, full namespaced names
//   <program>.dat_constants.csv     columns: name,address,read_only,qword_hex,double_LE
//
// Run as a -postScript (gd.py already does this and passes the output dir as arg 0).
//
// @category Pandora

import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.cmd.function.CreateFunctionCmd;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSpace;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.listing.Program;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.RefType;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;
import ghidra.program.model.symbol.ReferenceManager;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.symbol.SymbolIterator;
import ghidra.program.model.symbol.SymbolTable;
import ghidra.framework.options.Options;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.TreeSet;

public class GhidraPostExport extends GhidraScript {

    private static final int DECOMP_TIMEOUT_SECONDS = 120;   // per function
    private static final int MAX_RECOVERY_ROUNDS     = 4;    // fixpoint cap

    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        File outDir = (args != null && args.length > 0) ? new File(args[0]) : new File(".");
        if (!outDir.isDirectory()) {
            outDir.mkdirs();
        }
        String base = currentProgram.getName();   // e.g. PandoraAsymptoticFormula.dll

        // 1) turn on the options that most affect names/prototypes, best-effort.
        println("recovering C++ classes (RTTI + demangler) and missing functions");
        enableHelpfulOptions();

        // 2) aggressively create functions that auto-analysis missed.
        int recovered = recoverMissingFunctions();
        println("[post] recovered " + recovered + " additional functions");

        // 3) re-run analysis so the new functions get prototypes/types before decompiling.
        if (recovered > 0) {
            try {
                analyzeChanges(currentProgram);
            } catch (Exception e) {
                println("[post] analyzeChanges after recovery failed (continuing): " + e.getMessage());
            }
        }

        // 4) decompile EVERY function.
        println("exporting full C");
        decompileAll(new File(outDir, base + ".decompiled.c"));

        // 5) dump the DAT_ scalar constants (one qword each) for the merge step.
        int datCount = dumpDatConstants(new File(outDir, base + ".dat_constants.csv"));
        println("DAT_ entries: " + datCount);

        println("[post] DONE");
    }

    // ---------------------------------------------------------------- options
    private void enableHelpfulOptions() {
        try {
            Options opt = currentProgram.getOptions(Program.ANALYSIS_PROPERTIES);
            // These names differ slightly across Ghidra versions; setting a name that
            // does not exist is harmless, so we just try the common ones.
            String[] on = {
                "Decompiler Parameter ID",
                "Decompiler Switch Analysis",
                "Demangler Microsoft",
                "Demangler GNU",
                "Windows x86 PE RTTI Analyzer",
                "Windows x86 PE Exception Handling",
                "Aggressive Instruction Finder",
                "Create Address Tables",
                "Function Start Search",
            };
            for (String name : on) {
                try { opt.setBoolean(name, true); } catch (Exception ignore) { }
            }
        } catch (Exception e) {
            println("[post] could not set analysis options (continuing): " + e.getMessage());
        }
    }

    // ------------------------------------------------------- function recovery
    private int recoverMissingFunctions() throws Exception {
        Listing listing       = currentProgram.getListing();
        FunctionManager fm     = currentProgram.getFunctionManager();
        ReferenceManager rm    = currentProgram.getReferenceManager();
        Memory mem             = currentProgram.getMemory();

        int totalCreated = 0;
        for (int round = 0; round < MAX_RECOVERY_ROUNDS && !monitor.isCancelled(); round++) {
            TreeSet<Address> candidates = new TreeSet<>();

            // (a) every call / jump destination that is in executable memory.
            ReferenceIterator refs = rm.getReferenceIterator(currentProgram.getMinAddress());
            while (refs.hasNext() && !monitor.isCancelled()) {
                Reference r = refs.next();
                RefType t = r.getReferenceType();
                if (t == null || !(t.isCall() || t.isJump())) {
                    continue;
                }
                Address to = r.getToAddress();
                if (isExecutable(to) && fm.getFunctionAt(to) == null) {
                    candidates.add(to);
                }
            }

            // (b) function pointers parked in read-only data (vtable / dispatch slots).
            collectExecPointers(candidates);

            // (c) realise the candidates: disassemble if needed, then create a function.
            int createdThisRound = 0;
            for (Address a : candidates) {
                if (monitor.isCancelled()) break;
                if (fm.getFunctionAt(a) != null) continue;
                try {
                    if (listing.getInstructionAt(a) == null) {
                        DisassembleCommand dis = new DisassembleCommand(a, null, true);
                        dis.applyTo(currentProgram, monitor);
                    }
                    CreateFunctionCmd cfc = new CreateFunctionCmd(a);
                    if (cfc.applyTo(currentProgram, monitor)) {
                        createdThisRound++;
                    }
                } catch (Exception ignore) {
                    // leave it; a later round or analysis may pick it up
                }
            }

            totalCreated += createdThisRound;
            println("[post] recovery round " + (round + 1) + ": +" + createdThisRound + " functions");
            if (createdThisRound == 0) {
                break;   // fixpoint reached
            }
        }
        return totalCreated;
    }

    /** Scan initialised, non-writable, non-executable blocks (.rdata-like) for 8-byte
     *  values that point into executable memory -- i.e. vtable / dispatch function slots. */
    private void collectExecPointers(TreeSet<Address> out) throws Exception {
        Memory mem = currentProgram.getMemory();
        AddressSpace space = currentProgram.getAddressFactory().getDefaultAddressSpace();
        byte[] b = new byte[8];
        for (MemoryBlock blk : mem.getBlocks()) {
            if (!blk.isInitialized() || blk.isWrite() || blk.isExecute()) continue;
            Address a = blk.getStart();
            Address end = blk.getEnd();
            while (a.compareTo(end) <= 0 && !monitor.isCancelled()) {
                try {
                    if (mem.getBytes(a, b) == 8) {
                        long v = 0;
                        for (int k = 7; k >= 0; k--) {
                            v = (v << 8) | (b[k] & 0xffL);   // little-endian qword
                        }
                        if (v != 0) {
                            Address t = space.getAddress(v);
                            MemoryBlock tb = mem.getBlock(t);
                            if (tb != null && tb.isExecute()
                                    && currentProgram.getFunctionManager().getFunctionAt(t) == null) {
                                out.add(t);
                            }
                        }
                    }
                } catch (Exception ignore) {
                    // not a valid address / unreadable -- skip
                }
                Address next = a.add(8);
                if (next == null || next.compareTo(a) <= 0) break;
                a = next;
            }
        }
    }

    private boolean isExecutable(Address a) {
        if (a == null || !a.isMemoryAddress()) return false;
        MemoryBlock b = currentProgram.getMemory().getBlock(a);
        return b != null && b.isExecute();
    }

    // ------------------------------------------------------------- decompile
    private void decompileAll(File outFile) throws Exception {
        DecompInterface decomp = new DecompInterface();
        DecompileOptions opts = new DecompileOptions();
        decomp.setOptions(opts);
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) {
            println("[post] ERROR: could not open program in decompiler: "
                    + decomp.getLastMessage());
            decomp.dispose();
            return;
        }

        FunctionManager fm = currentProgram.getFunctionManager();
        int total = fm.getFunctionCount();
        int i = 0, ok = 0, failed = 0;

        try (PrintWriter w = new PrintWriter(new BufferedWriter(new FileWriter(outFile)))) {
            w.println("// Full decompilation of " + currentProgram.getName());
            w.println("// Image base: " + currentProgram.getImageBase());
            w.println("// Functions in program: " + total);
            w.println("// (every function below, including non-exported internal C++ methods)");
            w.println();

            FunctionIterator it = fm.getFunctions(true);   // true = forward over ALL functions
            while (it.hasNext() && !monitor.isCancelled()) {
                Function fn = it.next();
                i++;

                String fullName = safeName(fn);
                String addr = fn.getEntryPoint().toString();

                if (fn.isThunk()) {
                    Function thunked = fn.getThunkedFunction(true);
                    w.println();
                    w.println("// " + addr + "  " + fullName
                            + "   [THUNK -> " + (thunked != null ? safeName(thunked) : "?") + "]");
                    ok++;
                    continue;
                }

                DecompileResults r = null;
                try {
                    r = decomp.decompileFunction(fn, DECOMP_TIMEOUT_SECONDS, monitor);
                } catch (Exception e) {
                    // fall through to the failed branch
                }

                w.println();
                if (r != null && r.decompileCompleted() && r.getDecompiledFunction() != null) {
                    w.println("// " + addr + "  " + fullName);
                    w.println(r.getDecompiledFunction().getC());
                    ok++;
                } else {
                    String msg = (r != null && r.getErrorMessage() != null)
                            ? r.getErrorMessage() : "no result";
                    w.println("// " + addr + "  " + fullName + "   -- DECOMPILE FAILED: " + msg);
                    failed++;
                }

                if (i % 250 == 0) {
                    println("[post]  decompiled " + i + "/" + total + " functions...");
                }
            }
            w.flush();
        }

        decomp.dispose();
        println("[post] decompiled " + ok + " functions, " + failed + " failed, of " + total);
    }

    /** Fully-qualified, demangled name when available (e.g. Class::method); falls back gracefully. */
    private String safeName(Function fn) {
        try {
            return fn.getName(true);   // include namespace path
        } catch (Exception e) {
            return fn.getName();
        }
    }

    // ------------------------------------------------------------- DAT_ dump
    private int dumpDatConstants(File outFile) throws Exception {
        Memory mem = currentProgram.getMemory();
        SymbolTable st = currentProgram.getSymbolTable();
        byte[] b = new byte[8];
        int count = 0;

        try (PrintWriter w = new PrintWriter(new BufferedWriter(new FileWriter(outFile)))) {
            w.println("name,address,read_only,qword_hex,double_LE");

            SymbolIterator it = st.getAllSymbols(true);
            while (it.hasNext() && !monitor.isCancelled()) {
                Symbol s = it.next();
                String nm = s.getName();
                if (nm == null) continue;
                if (!(nm.startsWith("DAT_") || nm.startsWith("_DAT_"))) continue;

                Address a = s.getAddress();
                if (a == null || !a.isMemoryAddress()) continue;
                MemoryBlock blk = mem.getBlock(a);
                if (blk == null || !blk.isInitialized()) {
                    // still record it, marked non-read-only with no value
                    w.println(nm + "," + a + "," + "no" + "," + "" + "," + "");
                    count++;
                    continue;
                }

                boolean ro = !blk.isWrite();
                String qhex = "";
                String dstr = "";
                try {
                    if (mem.getBytes(a, b) == 8) {
                        long v = 0;
                        for (int k = 7; k >= 0; k--) {
                            v = (v << 8) | (b[k] & 0xffL);   // little-endian
                        }
                        qhex = String.format("%016x", v);
                        dstr = Double.toString(Double.longBitsToDouble(v));
                    }
                } catch (Exception ignore) { }

                w.println(nm + "," + a + "," + (ro ? "yes" : "no") + "," + qhex + "," + dstr);
                count++;
            }
            w.flush();
        }
        return count;
    }
}
