#!/usr/bin/env python3
"""
gd.py  -- run this with your normal Python:  python gd.py

It pops up boxes asking for:
  1. the DLL to decompile
  2. your Ghidra install folder  (only if it cannot auto-detect it)
  3. the output folder           (Cancel = this script's own folder)
then drives Ghidra in headless mode to:
  - analyze the DLL (with Decompiler Parameter ID, RTTI, demangler, switch analysis)
  - recover C++ classes from RTTI
  - decompile every function to one .c file
  - dump every DAT_ constant value to a .csv

Needs: Ghidra + a JDK already installed (NOT pip-installable). No pip packages required here
(Tkinter is part of the standard library; if it is missing, the script falls back to console prompts).
"""
import os, sys, subprocess, tempfile, glob

HERE = os.path.dirname(os.path.abspath(__file__))
IS_WIN = (os.name == "nt")
HEADLESS = "analyzeHeadless.bat" if IS_WIN else "analyzeHeadless"


def find_ghidra():
    """Best-effort auto-detect of a Ghidra install (the folder containing support/analyzeHeadless)."""
    for var in ("GHIDRA_INSTALL_DIR", "GHIDRA_HOME", "GHIDRA_DIR", "GHIDRA_ROOT"):
        p = os.environ.get(var)
        if p and os.path.isfile(os.path.join(p, "support", HEADLESS)):
            return p
    home = os.path.expanduser("~")
    roots = [home, os.path.join(home, "Desktop"), os.path.join(home, "Downloads"),
             os.path.join(home, "Documents"), os.path.join(home, "Tools"),
             "/opt", "/usr/share", "/usr/local", "/Applications",
             "C:\\", "C:\\Program Files", "C:\\Program Files (x86)", "C:\\Tools", "C:\\ghidra"]
    cands = []
    for r in roots:
        try:
            cands += glob.glob(os.path.join(r, "ghidra_*"))
            cands += glob.glob(os.path.join(r, "ghidra_*", "ghidra_*"))   # nested unzip
            cands += glob.glob(os.path.join(r, "ghidra*", "ghidra_*"))
        except Exception:
            pass
    for c in cands:
        if os.path.isfile(os.path.join(c, "support", HEADLESS)):
            return c
    return None


def get_inputs_gui(default_ghidra):
    import tkinter as tk
    from tkinter import filedialog, messagebox
    root = tk.Tk(); root.withdraw()
    messagebox.showinfo("Ghidra decompiler", "Step 1 of 3: choose the DLL (or EXE) to decompile.")
    dll = filedialog.askopenfilename(title="Select the DLL to decompile",
                                     filetypes=[("Binaries", "*.dll *.exe"), ("All files", "*.*")])
    if not dll:
        root.destroy(); return None
    ghidra = default_ghidra
    if not ghidra:
        messagebox.showinfo("Ghidra location",
                            "Ghidra was not auto-detected.\nStep 2 of 3: choose your Ghidra install "
                            "folder (the one that contains a 'support' folder).")
        ghidra = filedialog.askdirectory(title="Select your Ghidra install folder")
        if not ghidra:
            root.destroy(); return None
    messagebox.showinfo("Output folder",
                        "Step 3 of 3: choose where to write the .c output.\n"
                        "Press Cancel to use this script's folder:\n" + HERE)
    out = filedialog.askdirectory(title="Output folder (Cancel = this script's folder)")
    if not out:
        out = HERE
    root.destroy()
    return dll, ghidra, out


def get_inputs_console(default_ghidra):
    print("\n(Tkinter not available - using console prompts.)\n")
    dll = input("Full path to the DLL/EXE: ").strip().strip('"')
    if not dll:
        return None
    ghidra = default_ghidra
    if ghidra:
        print("Auto-detected Ghidra at: %s" % ghidra)
        alt = input("Press Enter to use it, or type another Ghidra install folder: ").strip().strip('"')
        if alt:
            ghidra = alt
    else:
        ghidra = input("Ghidra install folder (contains 'support'): ").strip().strip('"')
        if not ghidra:
            return None
    out = input("Output folder (Enter = this script's folder): ").strip().strip('"')
    if not out:
        out = HERE
    return dll, ghidra, out


import threading, time, math

# ---------------------------------------------------------------------------
# clean progress bar (replaces Ghidra's wall of log lines)
# ---------------------------------------------------------------------------
try:
    "█".encode(sys.stdout.encoding or "utf-8")
    _FILL, _EMPTY = "█", "·"
except Exception:
    _FILL, _EMPTY = "#", "-"


class Bar:
    def __init__(self, width=28, enabled=True):
        self.width = width
        self.enabled = enabled

    def update(self, pct, label=""):
        if not self.enabled:
            return
        pct = max(0.0, min(100.0, float(pct)))
        filled = int(round(self.width * pct / 100.0))
        line = "\r[%s%s] %3d%%  %-26.26s" % (
            _FILL * filled, _EMPTY * (self.width - filled), int(pct), label)
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
        except Exception:
            pass

    def finish(self):
        if not self.enabled:
            return
        try:
            sys.stdout.write("\n")
            sys.stdout.flush()
        except Exception:
            pass


def run_with_bar(cmd, log_path, bar, lo, hi, label, markers=None, tau=45.0, verbose=False):
    """Run cmd. In verbose mode the output streams to the console as normal (no bar).
    Otherwise the output is captured to log_path and a single-line bar is animated
    from lo toward hi: it time-crawls within the band and snaps forward whenever a
    (substring, pct) marker is seen in the output. Returns the process return code."""
    if verbose:
        return subprocess.call(cmd)
    markers = markers or []
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            bufsize=1, universal_newlines=True, errors="replace")
    shared = {"pct": float(lo)}

    def _reader():
        try:
            with open(log_path, "w", encoding="utf-8", errors="replace") as lf:
                for line in proc.stdout:
                    lf.write(line)
                    for sub, p in markers:
                        if sub in line and p > shared["pct"]:
                            shared["pct"] = float(p)
        except Exception:
            pass

    th = threading.Thread(target=_reader, daemon=True)
    th.start()
    start = time.time()
    while proc.poll() is None:
        elapsed = time.time() - start
        crawl = lo + (hi - lo) * (1.0 - math.exp(-elapsed / tau)) * 0.9
        bar.update(min(max(shared["pct"], crawl), hi - 0.5), label)
        time.sleep(0.25)
    th.join(timeout=2.0)
    bar.update(hi, label)
    return proc.returncode


def main():
    verbose = ("--verbose" in sys.argv) or ("-v" in sys.argv)
    name_filter = None
    for i, a in enumerate(sys.argv):
        if a == "--filter" and i + 1 < len(sys.argv):
            name_filter = sys.argv[i + 1]
        elif a.startswith("--filter="):
            name_filter = a.split("=", 1)[1]
    default_ghidra = find_ghidra()
    try:
        import tkinter  # noqa
        picked = get_inputs_gui(default_ghidra)
    except Exception:
        picked = get_inputs_console(default_ghidra)
    if not picked:
        print("Cancelled.")
        return 1
    dll, ghidra, out = picked

    headless = os.path.join(ghidra, "support", HEADLESS)
    problems = []
    if not os.path.isfile(dll):
        problems.append("DLL not found: %s" % dll)
    if not os.path.isfile(headless):
        problems.append("analyzeHeadless not found under: %s (is this the Ghidra install folder?)" % ghidra)
    if not os.path.isdir(out):
        try:
            os.makedirs(out)
        except Exception:
            problems.append("Output folder invalid: %s" % out)
    if not os.path.isfile(os.path.join(HERE, "GhidraPostExport.java")):
        problems.append("Missing helper script next to launcher: GhidraPostExport.java")
    if problems:
        print("\n".join("ERROR: " + p for p in problems))
        return 2

    base = os.path.basename(dll)
    ghidra_log = os.path.join(out, base + ".ghidra.log")
    proj_dir = tempfile.mkdtemp(prefix="ghidra_proj_")
    cmd = [headless, proj_dir, "tmpproj",
           "-import", dll,
           "-scriptPath", HERE,
           "-postScript", "GhidraPostExport.java", out]
    if name_filter:
        cmd.append(name_filter)
    cmd += ["-deleteProject", "-overwrite"]

    bar = Bar(enabled=not verbose)
    print("Decompiling  %s" % base)
    if verbose:
        print("(verbose: full logs follow)\n  " +
              " ".join('"%s"' % c if " " in c else c for c in cmd) + "\n")
    else:
        print("(full Ghidra log -> %s ; pass --verbose to watch it live)" % os.path.basename(ghidra_log))
    bar.update(2, "Starting Ghidra…")

    # ---- 1) Ghidra: analyze + RTTI + C export + DAT_ dump  (band 3 -> 78) ----
    rc = run_with_bar(
        cmd, ghidra_log, bar, 3, 78, "Analyzing in Ghidra…",
        markers=[("recovering C++", 58), ("exporting full C", 68),
                 ("DAT_ entries", 75), ("[post] DONE", 78)],
        tau=60.0, verbose=verbose)
    if rc != 0:
        bar.finish()
        print("Ghidra exited with code %d." % rc)
        print("The full log is here -> %s" % ghidra_log)
        return rc

    cs = sorted(glob.glob(os.path.join(out, "*.decompiled.c")), key=os.path.getmtime)
    vs = sorted(glob.glob(os.path.join(out, "*.dat_constants.csv")), key=os.path.getmtime)
    if not cs and not vs:
        bar.finish()
        print("Ghidra finished but produced no .decompiled.c / .csv -- the export script did not")
        print("run to completion. Look in the log for 'ERROR' -> %s" % ghidra_log)
        return 0

    # ---- 2) bulk .rdata table extraction  (band 78 -> 90) ----
    extractor = os.path.join(HERE, "extract_rdata_tables.py")
    idx = None
    if os.path.isfile(extractor) and vs:
        rc2 = run_with_bar(
            [sys.executable, extractor, dll, vs[-1], "--out", out],
            os.path.join(out, base + ".rdata_extract.log"), bar, 78, 90,
            "Extracting .rdata tables…",
            markers=[("wrote raw", 82), ("flat f64", 84),
                     ("catalogued", 88), ("[rdata] DONE", 90)],
            tau=10.0, verbose=verbose)
        ix = sorted(glob.glob(os.path.join(out, "*.rdata_tables_index.csv")), key=os.path.getmtime)
        idx = ix[-1] if ix else None
        if rc2 == 2 and idx is None and not verbose:
            # pefile missing -> carry on without table annotations
            pass

    # ---- 3) fold values into the C, table-aware  (band 90 -> 99) ----
    merger = os.path.join(HERE, "merge_dat_into_c.py")
    c_annot = c_inline = None
    if cs and vs and os.path.isfile(merger):
        c_in, v_in = cs[-1], vs[-1]
        c_annot = c_in.replace(".decompiled.c", ".decompiled.with_values.c")
        if c_annot == c_in:
            c_annot = c_in + ".with_values.c"
        c_inline = c_in.replace(".decompiled.c", ".decompiled.with_values.inlined.c")
        if c_inline == c_in:
            c_inline = c_in + ".with_values.inlined.c"
        tbl = (["--tables", idx] if idx else [])
        embed = (["--dll", dll] if idx else [])   # makes the inlined file self-contained
        mlog = os.path.join(out, base + ".merge.log")
        run_with_bar([sys.executable, merger, c_in, v_in, c_annot] + tbl,
                     mlog, bar, 90, 94, "Folding values into C…", verbose=verbose)
        run_with_bar([sys.executable, merger, c_in, v_in, c_inline, "--inline"] + tbl + embed,
                     mlog, bar, 94, 99, "Embedding tables into C…", verbose=verbose)

    bar.update(100, "Done")
    bar.finish()

    # ---- final summary: what was produced and where ----
    print("\nDone. Output folder:")
    print("  %s\n" % os.path.abspath(out))
    self_contained = idx and c_inline and os.path.isfile(c_inline)
    rows = [
        (c_inline, "decompiled C, constants inlined + full data tables embedded"
                   + ("  <-- self-contained, read this one" if self_contained
                      else "  <-- best for reading the math")),
        (c_annot,  "decompiled C, every DAT_ annotated (table previews only)"),
        (idx,      "catalogue of the .rdata data tables (now also inside the inlined .c)"),
        (cs[-1] if cs else None, "raw decompiled C"),
        (vs[-1] if vs else None, "DAT_ constant values (csv)"),
    ]
    for p, desc in rows:
        if p and os.path.isfile(p):
            print("  %-52s %s" % (os.path.basename(p), desc))
    tdir = os.path.join(out, base + ".rdata_tables")
    if os.path.isdir(tdir):
        print("  %-52s %s" % (base + ".rdata_tables/", "per-table data files (now also inside the inlined .c)"))
    if self_contained:
        print("\nThe inlined .c now contains the full table data, so #3 and the tables folder are optional.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
