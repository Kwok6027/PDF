#!/usr/bin/env python3
r"""
collect_check.py  --  gather the files worth scanning into one 'Check' folder.

Put this script in the folder that holds your per-DLL output folders
(PandoraAlgorithm\, PandoraExoticModel\, PricingManager\, ...) and run it:

    python collect_check.py

It walks every subfolder and copies into a new 'Check' folder:
  * each .dll
  * the best single .c per DLL  -- it prefers  *.decompiled.with_values.c,
    falls back to the raw  *.decompiled.c, and SKIPS the giant *.inlined.c
It leaves behind logs, .npy, .bin, .csv, rdata_tables\, manifests, .rep, etc.

The result is a clean, scan-ready folder to point code_scan.py at
(then run  need: / symbol: / find: / body:  against it).

Options:
    python collect_check.py --src <folder>      # scan a different folder (default: this script's folder)
    python collect_check.py --dest <folder>     # output folder (default: <src>\Check)
    python collect_check.py --clean             # empty Check first
    python collect_check.py --dry-run           # list what would be copied; copy nothing
    python collect_check.py --copy-inlined      # also copy the huge *.inlined.c (not recommended)
    python collect_check.py --exclude rep "Complied C"   # skip folders whose name contains these
    python collect_check.py --exts .dll .exe    # which binaries to copy (default .dll)
"""
import argparse
import os
import shutil
import sys

C_EXT = ".c"


def is_inlined(name):
    return "inlined" in name.lower()


def is_with_values(name):
    return "with_values" in name.lower()


def cbase(name):
    """Group all .c variants of one DLL: strip from '.decompiled' onward."""
    low = name.lower()
    i = low.find(".decompiled")
    return name[:i] if i != -1 else name


def main(argv=None):
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(
        description="Collect each .dll + the best .c per DLL into a 'Check' folder.")
    ap.add_argument("--src", default=here,
                    help="root folder to scan (default: this script's own folder)")
    ap.add_argument("--dest", default=None, help="output folder (default: <src>/Check)")
    ap.add_argument("--clean", action="store_true", help="empty the Check folder first")
    ap.add_argument("--copy-inlined", action="store_true",
                    help="also copy the giant *.inlined.c (not recommended)")
    ap.add_argument("--exclude", nargs="*", default=[],
                    help="skip folders whose name contains any of these substrings")
    ap.add_argument("--exts", nargs="*", default=[".dll"],
                    help="binary extensions to copy (default: .dll)")
    ap.add_argument("--dry-run", action="store_true",
                    help="show what would be copied; copy nothing")
    args = ap.parse_args(argv)

    src = os.path.realpath(os.path.expanduser(args.src))
    dest = (os.path.realpath(os.path.expanduser(args.dest))
            if args.dest else os.path.join(src, "Check"))
    bin_exts = set((e if e.startswith(".") else "." + e).lower() for e in args.exts)
    excludes = [x.lower() for x in args.exclude]

    if not os.path.isdir(src):
        print("ERROR: source folder not found:", src)
        return 2

    # ---- gather (don't descend into Check or excluded folders) ----
    dlls = []
    cfiles = []
    for dp, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not any(x in d.lower() for x in excludes)]
        rp = os.path.realpath(dp)
        if rp == dest or rp.startswith(dest + os.sep):
            dirs[:] = []
            continue
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            full = os.path.join(dp, f)
            if ext in bin_exts:
                dlls.append(full)
            elif ext == C_EXT:
                if is_inlined(f) and not args.copy_inlined:
                    continue
                cfiles.append(full)

    # ---- pick the best .c per DLL (bases are unique per DLL) ----
    groups = {}
    for c in cfiles:
        groups.setdefault(cbase(os.path.basename(c)), []).append(c)
    chosen_c = []
    for _key, variants in groups.items():
        wv = [v for v in variants
              if is_with_values(os.path.basename(v)) and not is_inlined(os.path.basename(v))]
        noninl = [v for v in variants if not is_inlined(os.path.basename(v))]
        if wv:
            chosen_c.append(wv[0])
        elif noninl:
            chosen_c.append(noninl[0])
        elif variants:
            chosen_c.append(variants[0])

    to_copy = sorted(set(dlls)) + sorted(set(chosen_c))

    print("=" * 70)
    print("source :", src)
    print("dest   :", dest)
    print("found  : %d dll, %d c (best variant per DLL)" % (len(set(dlls)), len(chosen_c)))
    if args.dry_run:
        print("DRY RUN -- nothing will be copied")
    print("=" * 70)

    if not args.dry_run:
        if args.clean and os.path.isdir(dest):
            shutil.rmtree(dest)
        os.makedirs(dest, exist_ok=True)

    copied = 0
    skipped = 0
    total = 0
    seen = {}
    for srcpath in to_copy:
        name = os.path.basename(srcpath)
        rel = os.path.relpath(srcpath, src)
        target = os.path.join(dest, name)
        # rare collision: same filename from two different folders -> prefix with the folder
        if name in seen and os.path.realpath(seen[name]) != os.path.realpath(srcpath):
            parent = os.path.basename(os.path.dirname(srcpath))
            target = os.path.join(dest, parent + "__" + name)
        seen[name] = srcpath
        if args.dry_run:
            print("  would copy:", rel)
            continue
        try:
            shutil.copy2(srcpath, target)
            copied += 1
            total += os.path.getsize(target)
        except Exception as e:
            print("  FAILED %s (%r)" % (rel, e))
            skipped += 1

    print("=" * 70)
    if args.dry_run:
        print("would copy %d files into %s" % (len(to_copy), dest))
    else:
        print("copied %d files (%.1f MB) into %s" % (copied, total / 1e6, dest))
        if skipped:
            print("skipped %d (errors)" % skipped)
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
