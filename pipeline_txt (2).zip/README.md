NOTE: To get past file-type filters, the code files in this zip are shipped with a
".txt" extension. After unzipping, remove the trailing ".txt" from each so they end in:
  run_ghidra_decompile.py      (Python - the one you run)
  merge_dat_into_c.py          (Python)
  GhidraPostExport.java        (Java - Ghidra runs this; you never run it directly)
Keep all three in the same folder. Nothing to install beyond Ghidra + a JDK.

----------------------------------------------------------------------

# Automated Ghidra decompile pipeline

Turns a DLL/EXE into decompiled C with one command, fully automated (no clicking,
no per-field decisions).

## What you need (once)
- **Ghidra** installed (download + unzip) and a **JDK 17 or 21**. These are NOT
  pip-installable, but Ghidra needs them anyway.
- Nothing else to install. The launcher uses only the Python standard library, and the
  in-Ghidra helper is plain **Java**, which Ghidra compiles with its own JDK -- so there
  is NO Jython, NO PyGhidra, and NO pip install required.

## Why Java for the helper (Ghidra 11.4 / 12.x)
Recent Ghidra removed the bundled Jython interpreter. Running a `.py` script now either
needs PyGhidra enabled (`pip install pyghidra` + launching Ghidra in PyGhidra mode) or a
separately installed Jython extension. To avoid all of that, the one script Ghidra runs
internally (`GhidraPostExport.java`) is written in Java, which always works out of the box.
You never run or edit it directly -- the Python launcher hands it to Ghidra for you.

## Files (keep all three in the same folder)
- `run_ghidra_decompile.py`  - the launcher. Run THIS with your normal Python.
- `GhidraPostExport.java`     - the in-Ghidra helper (RTTI recovery + decompile + DAT_ dump).
- `merge_dat_into_c.py`       - folds the DAT_ values back into the .c (the launcher runs it for you).

## How to run
```
python run_ghidra_decompile.py
```
It pops up three boxes:
1. choose the DLL/EXE,
2. choose your Ghidra install folder (only if it can't auto-detect it; you can also
   set the env var GHIDRA_INSTALL_DIR to skip this),
3. choose the output folder (Cancel = the launcher's own folder).

Then it runs Ghidra headless and, when finished, writes into the output folder:
- `<name>.decompiled.c`             - every function decompiled to C
- `<name>.dat_constants.csv`        - every DAT_ constant: address, read-only flag,
                                      raw qword, little-endian double, and any typed value
- `<name>.decompiled.with_values.c` - the .c with the DAT_ values folded in (READ THIS ONE):
                                      a header table of all constants, plus a /* DAT: ... */
                                      note on every line that uses one (value, or <runtime>).

To also substitute read-only doubles in place (DAT_x -> (0.5)) for the most readable
formulas, re-run the merge yourself with --inline:
```
python merge_dat_into_c.py <name>.decompiled.c <name>.dat_constants.csv out.c --inline
```
(NOTE: if your DLL's image base is not 0x180000000, edit IMAGE_BASE at the top of
merge_dat_into_c.py so pointer-vs-double classification stays correct.)

## What it does automatically
1. Imports + runs Ghidra's default auto-analysis on the binary.
2. Runs RTTI class recovery (RecoverClassesFromRTTIScript) to rebuild C++ classes/vtables.
3. Decompiles every function into the single .c file.
4. Dumps all DAT_ constant values (non-destructive - it reads bytes, it does not retype).
5. Merges the values into the C.

(Optional manual extras in the Ghidra GUI, if you want them later: enable "Decompiler
Parameter ID" with Prototype Evaluation = __thiscall for better parameter naming. This
affects names, not the arithmetic.)

## Honest limits
- Output is offset-correct and type-inferred but **auto-named** (fields like
  `field_0x30`, locals like `lVar1`). Names don't affect the math; offsets/types are
  derived from the machine code.
- It will NOT undo compiler optimizations (FMA, vectorization, divide-by-constant).
- Only READ-ONLY (.rdata) DAT_ entries have a real static value; writable globals
  read as runtime state (the `read_only` column tells you which is which).

The Java helper uses only stable Ghidra API, but it could not be test-run against a live
Ghidra here, so if anything errors, copy the console output and I'll fix it.
