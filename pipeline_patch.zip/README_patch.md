# Pipeline patch: readable output for replication + clean progress bar

Drop these into the **same folder** as `GhidraPostExport.java`, strip the trailing
`.txt`, and overwrite the old files:

```
gd.py        (replaces the launcher)
merge_dat_into_c.py            (replaces the merger -- now table-aware)
extract_rdata_tables.py        (new -- bulk .rdata extraction)
```

`GhidraPostExport.java` is unchanged; keep your existing copy.

Dependency for the `.rdata` step: `pip install pefile` (and `numpy`, optional). The
decompile + merge still run with the standard library only; if `pefile` is missing,
that one step is skipped and everything else proceeds.

## What changed (and why it helps replication)

The goal is to make the decompiled C as close to the real calculation as the tooling
can get, so you can re-implement and verify it.

1. **Arrays are now shown AS ARRAYS.** Previously every `DAT_` was labelled from a
   single dumped qword, so an array base looked like one scalar (`DAT_x=0.5`) — which
   is *actively misleading* when you're trying to replicate a formula, because that
   address is really, say, a 256-element coefficient table. The merger now cross-checks
   the `.rdata` table catalogue and renders those as
   `DAT_x=f64[256 doubles] {0.1, 0.2, ...} [min..max]`, with the full values in the
   `…rdata_tables/` folder. Scalars still show their value.
2. **Constants are inlined into the formulas.** A second output file substitutes the
   literal value for every read-only *scalar* double (`x * DAT_a` -> `x * (0.5)`), so the
   math reads directly. Array bases are deliberately **not** inlined (you can't replace
   an array with one number).
3. **Bulk `.rdata` is captured** (the `extract_rdata_tables.py` step) — the whole
   section as raw bytes + a per-table breakdown — so the tables your formulas index
   are actually available, not just their first element.

## New / changed outputs (in the output folder)

- `<name>.decompiled.with_values.inlined.c` — **start here for the math.** Decompiled C
  with scalar constants inlined and every `DAT_` annotated.
- `<name>.decompiled.with_values.c` — same annotations, constants left as `DAT_`.
- `<name>.decompiled.c` — raw decompiler output.
- `<name>.dat_constants.csv` — every `DAT_`: address, read-only flag, qword, double.
- `<name>.rdata_tables_index.csv` — catalogue of every data table (start, length,
  element count, kind, min/max, preview).
- `<name>.rdata_tables/` — one file per substantial table (doubles -> `.npy`/`.csv`).
- `<name>.rdata.bin` / `.rdata.f64.npy` — the whole section raw / as float64.
- `<name>.ghidra.log`, `.rdata_extract.log`, `.merge.log` — full step logs (saved, not
  printed).

## The progress bar

`python gd.py` now hides Ghidra's wall of output and shows a single
progress line that climbs 0–100% across the three stages (analyze -> extract -> merge),
then prints the output folder and the files produced. Ghidra's full output still goes to
`<name>.ghidra.log` for debugging.

- Want the old, fully verbose output instead? add `--verbose` (or `-v`).
- If a step fails, the bar stops and the path to the relevant log is printed.

## Suggested replication workflow

1. Open `…with_values.inlined.c` and work **one function at a time**, starting from the
   exported entry points.
2. When a function indexes a `DAT_` table, open the matching file in `…rdata_tables/`
   to get the actual coefficients.
3. Re-implement the function in your own language; **validate numerically** — call the
   DLL with a spread of inputs and diff its output against your re-implementation
   (a golden-master / differential test). Match to tolerance before moving on.

## Honest limits

This makes the output far more interpretable, but it is **not** an automatic clean port:

- The decompiler will not undo compiler optimizations — fused multiply-add,
  vectorization, divide-by-constant turned into multiply-by-reciprocal, reordered
  associativity. The arithmetic is faithful but not in textbook form.
- Locals/fields are auto-named (`lVar1`, `field_0x30`). For cleaner *names* (not
  arithmetic), enable Ghidra's "Decompiler Parameter ID" with Prototype Evaluation =
  `__thiscall` in the GUI and re-export.
- Table boundaries from the `.rdata` step are heuristic (each table runs to the next
  label); confirm a table's true length against the loop bounds in the decompiled C.
- The `pefile`/Ghidra steps couldn't be test-run against your actual DLL here; the
  segmentation, classification, merge, and progress logic were unit-tested on synthetic
  data. If a step errors, send me the relevant `.log` and I'll fix it.
