#!/usr/bin/env python3
# =====================================================================
# code_scan.py  --  generic OFFLINE scanner for a folder of source / config files.
#
# Point it at a folder (it walks every subfolder), paste a REQUEST describing what
# to find, click Scan. It is product-agnostic: the request is data, not code, so the
# same tool answers any ask -- "find epsilonPut", "where is getVol defined", "numbers
# near 'skew'", etc.  Reads .c/.cpp/.h/.txt/.log/.json/.csv/.py/.java as text, .xml as
# text, and .xlsx via the standard library (no installs).  .xls is best-effort.
#
# IT IS FULLY LOCAL: it never makes a network call. Your files never leave the machine.
#
# RUN AS A GUI (double-click, or):     python code_scan.py
# RUN HEADLESS / SCRIPTABLE:           python code_scan.py --scan "C:\path" --request "epsilonPut"
#                                      python code_scan.py --scan "C:\path" --request-file req.txt
#
# ---------------------------------------------------------------------
# REQUEST SYNTAX  (one directive per line; blank lines and '#' comments ignored;
#                  a bare line with no prefix is treated as `find:`)
#
#   closure: NAME[,NAME2]  crawl the WHOLE call tree from NAME over the .c here: dump every
#                         reachable body in one pass, list the DLLs to decompile next, and
#                         flag indirect/vtable calls to resolve by hand.  (alias: trace:)
#   find: TEXT            case-insensitive substring search -> file:line + context
#   re:   PATTERN         regex search (case-insensitive)
#   def:  NAME            where is function NAME *defined* (real body)? shows the body head,
#                         its math (pow/sqrt/log/exp) and whether it's only ever CALLED
#   calls: NAME           list call sites of NAME
#   const: VALUE          numeric literals approx == VALUE   (default 0.5% rel tol)
#   const: VALUE ~ TOL    same, with your own relative tolerance (e.g. const: 0.0025 ~ 1e-3)
#   near:  KEYWORD        numbers appearing on lines that mention KEYWORD
#   ext:   .c .xml .xlsx  restrict the file types scanned (applies to the whole request)
#   list                 just inventory the files found, by type
# =====================================================================

import os
import re
import sys
import fnmatch
import zipfile
import xml.etree.ElementTree as ET

# ----------------------------------------------------------------- file types
TEXT_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".txt", ".log",
             ".json", ".csv", ".tsv", ".py", ".java", ".md", ".ini", ".cfg"}
XML_EXTS = {".xml"}
XLSX_EXTS = {".xlsx", ".xlsm"}
XLS_EXTS = {".xls"}
PE_EXTS = {".dll", ".exe", ".ocx"}
READABLE = TEXT_EXTS | XML_EXTS | XLSX_EXTS | XLS_EXTS

MAX_PER_FILE = 60          # cap matches shown per file per directive
MAX_CELLS = 60000          # cap cells read from a spreadsheet
NUM_RE = re.compile(r'[-+]?(?:\d+\.\d+|\.\d+|\d+)(?:[eE][-+]?\d+)?')

# ----------------------------------------------------------------- C-symbol helpers
KEYWORDS = set((
    "if else for while switch case do return sizeof typedef struct union enum const "
    "static unsigned signed void int char long short float double bool goto break "
    "continue default extern volatile register inline true false null").split())
PSEUDO = re.compile(r'^(CONCAT|SUB|ZEXT|SEXT|CARRY|SCARRY|SBORROW|POPCOUNT|ABS|NAN|'
                    r'in_|unaff_|extraout_|__)', re.I)


def _match_delims(text, open_idx, op, cl, max_span=None):
    depth = 0
    i = open_idx
    n = len(text)
    stop = n if max_span is None else min(n, open_idx + max_span)
    while i < stop:
        c = text[i]
        if c == op:
            depth += 1
        elif c == cl:
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def _classify(text, s, e):
    """Is the name occurrence at [s,e) a definition, a call, a comment annotation, or noise?"""
    nxt = text[e] if e < len(text) else ''
    if nxt.isalnum() or nxt == '_':
        return ('skip', None)
    ls = text.rfind('\n', 0, s) + 1
    if '//' in text[ls:s]:
        return ('comment', None)
    j = s - 1
    while j >= 0 and text[j].isspace():
        j -= 1
    prev = text[j] if j >= 0 else ''
    k = e
    while k < len(text) and text[k].isspace():
        k += 1
    if k >= len(text) or text[k] != '(':
        return ('other', None)
    if prev == '=':
        return ('call', None)
    cp = _match_delims(text, k, '(', ')', max_span=3000)
    if cp == -1:
        return ('other', None)
    m = cp + 1
    while m < len(text) and text[m].isspace():
        m += 1
    if m < len(text) and text[m] == '{':
        return ('def', m)
    return ('call', None)


def _analyze(text, base):
    """Return (list_of_(body_open_idx, def_char_idx), n_calls) for base name."""
    defs = []
    calls = 0
    for mo in re.finditer(r'(?<![A-Za-z0-9_])' + re.escape(base), text):
        kind, info = _classify(text, mo.start(), mo.end())
        if kind == 'def':
            defs.append((info, mo.start()))
        elif kind == 'call':
            calls += 1
    return defs, calls


def _body_of(text, open_idx):
    end = _match_delims(text, open_idx, '{', '}', max_span=600000)
    return text[open_idx:(end + 1 if end != -1 else open_idx + 4000)]


def _arith(body):
    return {op: len(re.findall(r'\b' + op + r'\s*\(', body)) for op in ("pow", "sqrt", "log", "exp", "erf")}


def _lineno(text, idx):
    return text.count('\n', 0, idx) + 1


# ----------------------------------------------------------------- readers
def read_xlsx_text(path):
    """Extract 'Sheet!Cell = value' lines from an .xlsx/.xlsm using only the stdlib."""
    out = []
    try:
        z = zipfile.ZipFile(path)
    except Exception:
        return ""
    def local(tag):
        return tag.rsplit('}', 1)[-1]
    # sheet names, in order
    names = []
    try:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        for el in wb.iter():
            if local(el.tag) == "sheet":
                names.append(el.attrib.get("name", ""))
    except Exception:
        pass
    # shared strings
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        try:
            sst = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in sst:
                if local(si.tag) != "si":
                    continue
                txt = "".join(t.text or "" for t in si.iter() if local(t.tag) == "t")
                shared.append(txt)
        except Exception:
            pass
    # sheets
    sheet_files = sorted(
        [n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n)],
        key=lambda n: int(re.search(r'(\d+)', n).group(1)))
    ncells = 0
    for i, sf in enumerate(sheet_files):
        sheet = names[i] if i < len(names) else "Sheet%d" % (i + 1)
        try:
            ws = ET.fromstring(z.read(sf))
        except Exception:
            continue
        for c in ws.iter():
            if local(c.tag) != "c":
                continue
            ref = c.attrib.get("r", "?")
            t = c.attrib.get("t")
            val = ""
            for ch in c:
                lt = local(ch.tag)
                if lt == "v":
                    val = ch.text or ""
                elif lt == "is":  # inline string
                    val = "".join(x.text or "" for x in ch.iter() if local(x.tag) == "t")
            if t == "s" and val.isdigit() and int(val) < len(shared):
                val = shared[int(val)]
            if val != "":
                out.append("%s!%s = %s" % (sheet, ref, val))
                ncells += 1
                if ncells >= MAX_CELLS:
                    out.append("... (cell cap reached)")
                    return "\n".join(out)
    return "\n".join(out)


def read_xls_text(path):
    """Legacy .xls: try a library if installed, else best-effort printable strings."""
    try:
        import pandas as pd  # optional
        xl = pd.read_excel(path, sheet_name=None, header=None, dtype=str)
        out = []
        for sheet, df in xl.items():
            for r, row in df.iterrows():
                for ci, v in enumerate(row):
                    if v is not None and str(v) != "nan":
                        out.append("%s!r%dc%d = %s" % (sheet, r + 1, ci + 1, v))
        return "\n".join(out)
    except Exception:
        pass
    try:
        raw = open(path, "rb").read()
        strs = re.findall(rb'[\x20-\x7e]{4,}', raw)
        return "\n".join(s.decode("ascii", "replace") for s in strs)
    except Exception:
        return ""


def read_text(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in XLSX_EXTS:
            return read_xlsx_text(path)
        if ext in XLS_EXTS:
            return read_xls_text(path)
        return open(path, "r", encoding="utf-8", errors="replace").read()
    except Exception:
        return ""


def iter_files(root, exts=None):
    for dirpath, _dirs, files in os.walk(root):
        for fn in files:
            ext = os.path.splitext(fn)[1].lower()
            if exts is not None:
                if ext not in exts:
                    continue
            elif ext not in READABLE:
                continue
            yield os.path.join(dirpath, fn)


# ----------------------------------------------------------------- PE symbol lookup
# Folds the find_symbol.py capability in: reads .dll/.exe export & import tables to say
# which binary DEFINES (exports) a symbol vs which only imports it. Uses pefile (the same
# library find_symbol.py relies on); degrades with a clear message if pefile is absent.
def _pe_symbol_match(path, base):
    import pefile
    pe = pefile.PE(path, fast_load=True)
    pe.parse_data_directories(directories=[
        pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT'],
        pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_IMPORT'],
    ])
    low = base.lower()
    exp = []
    if hasattr(pe, "DIRECTORY_ENTRY_EXPORT"):
        for s in pe.DIRECTORY_ENTRY_EXPORT.symbols:
            if s.name:
                nm = s.name.decode("ascii", "replace")
                if low in nm.lower():
                    exp.append(nm)
    imp = {}
    if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            dll = entry.dll.decode("ascii", "replace") if entry.dll else "?"
            hits = [i.name.decode("ascii", "replace") for i in entry.imports
                    if i.name and low in i.name.decode("ascii", "replace").lower()]
            if hits:
                imp[dll] = hits
    pe.close()
    return exp, imp


def run_symbol_table(dll_files, name):
    base = name.split("::")[-1]
    try:
        import pefile  # noqa: F401
    except Exception:
        return [("(pefile not installed)", 0,
                 ["This directive reads DLL export tables and needs pefile",
                  "(the same library your find_symbol.py uses).  pip install pefile",
                  "-- or keep using find_symbol.py for the binary side."])]
    if not dll_files:
        return [("(no .dll/.exe found)", 0,
                 ["No binaries in the folder. Put the .dll files in the scan folder too,",
                  "or this directive has nothing to read."])]
    blocks = []
    for path in dll_files:
        try:
            exp, imp = _pe_symbol_match(path, base)
        except Exception:
            continue
        info = []
        if exp:
            info.append("EXPORTS (defines): " + ", ".join(exp[:6]) + (" ..." if len(exp) > 6 else ""))
        for dll, hits in imp.items():
            info.append("imports from %s: %s" % (dll, ", ".join(hits[:4])))
        if info:
            blocks.append((path, len(exp) + sum(len(v) for v in imp.values()), info))
    return blocks


def run_need(files, dll_files, name):
    """Reconcile .c definitions against .dll exports and say, in plain words,
    whether a function is READY to read or whether a DLL still needs decompiling."""
    base = name.split("::")[-1]

    defined_in = []
    called_in = []
    for path, text in files:
        defs, calls = _analyze(text, base)
        if defs:
            defined_in.append(path)
        elif calls:
            called_in.append(path)
    c_names = [os.path.basename(p) for p, _t in files if p.lower().endswith(".c")]

    exporters = []
    importers = []
    pe_missing = False
    pe_ran = False
    for d in dll_files:
        try:
            exp, imp = _pe_symbol_match(d, base)
            pe_ran = True
            if exp:
                exporters.append(d)
            if imp:
                importers.append(d)
        except ImportError:
            pe_missing = True
            break
        except Exception:
            pe_ran = True
            continue

    L = []
    if defined_in:
        L.append(".c   : DEFINED in " + ", ".join(os.path.basename(p) for p in defined_in))
    else:
        L.append(".c   : not defined in any .c here"
                 + (" (only called, in %d file(s))" % len(called_in) if called_in else ""))
    if dll_files:
        if pe_missing:
            L.append(".dll : export check skipped -- pip install pefile to enable it")
        elif exporters:
            L.append(".dll : EXPORTED by " + ", ".join(os.path.basename(p) for p in exporters))
        elif pe_ran:
            L.append(".dll : not exported by any DLL here"
                     + ((" (imported by %s)" % ", ".join(os.path.basename(p) for p in importers))
                        if importers else ""))
    else:
        L.append(".dll : no DLLs in this folder to check -- add them so I can point to the source")

    L.append("")
    if defined_in:
        L.append("=> READY. The body is here; no decompile needed.")
    elif exporters:
        exp_name = os.path.basename(exporters[0])
        stem = os.path.splitext(exp_name)[0]
        already = any(c.startswith(stem) and ".decompiled" in c for c in c_names)
        L.append("=> DECOMPILE NEEDED: '%s' lives in %s, which is not decompiled in this folder." % (base, exp_name))
        L.append("   run:  python gd.py --dll <path>\\%s --out-dir <out>" % exp_name)
        if already:
            L.append("   note: a %s*.decompiled.c is present but does not define '%s' --" % (stem, base))
            L.append("         likely --filtered out or a failed decompile; re-run it (try --filter %s)." % base)
    elif importers and pe_ran:
        L.append("=> SOURCE DLL MISSING: '%s' is only imported (by %s); the DLL that defines it"
                 % (base, ", ".join(os.path.basename(p) for p in importers)))
        L.append("   is not in this folder. Add that DLL, then decompile it.")
    elif pe_missing:
        L.append("=> Can't locate the source: install pefile so the DLL export tables can be read,")
        L.append("   or add the decompiled .c that defines '%s'." % base)
    else:
        L.append("=> NOT FOUND here: no .c defines '%s' and no DLL in the folder exports it." % base)
        L.append("   Check the name, or add the relevant DLL / decompiled .c to the folder.")
    return L


# ----------------------------------------------------------------- OCR garble flag
GARBLE_SIGS = [r'reztuen', r'\bOx[0-9a-fA-F]', r'8x1[0-9a-fA-F]', r'@x[0-9a-fA-F]',
               r'\bBABE\b', r'\bBOE\b']


def garbled(text):
    score = sum(len(re.findall(s, text)) for s in GARBLE_SIGS)
    nonascii = sum(1 for ch in text[:200000] if ord(ch) > 127)
    return score >= 5 or (nonascii / max(1, min(len(text), 200000))) > 0.006


# ----------------------------------------------------------------- request parsing
def parse_request(req):
    """Return (directives, exts_filter_or_None, includes, excludes)."""
    directives = []
    exts = None
    includes = []
    excludes = []
    for raw in req.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        low = line.lower()
        if low.startswith("ext:") or low.startswith("only:"):
            exts = set()
            for tok in line.split(":", 1)[1].split():
                exts.add(tok if tok.startswith(".") else "." + tok)
            continue
        if low.startswith("files:") or low.startswith("include:"):
            includes += line.split(":", 1)[1].split()
            continue
        if low.startswith("skip:") or low.startswith("exclude:"):
            excludes += line.split(":", 1)[1].split()
            continue
        if low == "list":
            directives.append(("list", ""))
            continue
        for kind in ("closure", "trace", "crawl", "all",
                     "symbol", "need", "locate", "body", "def", "calls",
                     "const", "near", "re", "find"):
            if low.startswith(kind + ":"):
                directives.append((kind, line.split(":", 1)[1].strip()))
                break
        else:
            directives.append(("find", line))   # bare line == find
    return directives, exts, includes, excludes


# ----------------------------------------------------------------- directive runners
def _ctx(text_lines, ln, ctx=1):
    a = max(0, ln - 1 - ctx)
    b = min(len(text_lines), ln + ctx)
    return [(i + 1, text_lines[i]) for i in range(a, b)]


def run_find(files, needle, regex=False, ctx=1):
    pat = re.compile(needle if regex else re.escape(needle), re.I)
    blocks = []
    for path, text in files:
        lines = text.split("\n")
        hits = 0
        per = []
        for i, ln in enumerate(lines):
            if pat.search(ln):
                seg = "  | ".join("%d: %s" % (n, l.strip()[:160]) for n, l in _ctx(lines, i + 1, ctx))
                per.append(seg)
                hits += 1
                if hits >= MAX_PER_FILE:
                    per.append("    ... (%d+ matches, capped)" % MAX_PER_FILE)
                    break
        if per:
            blocks.append((path, hits, per))
    return blocks


def run_const(files, value, tol):
    lo, hi = value * (1 - tol), value * (1 + tol)
    if value == 0:
        lo, hi = -tol, tol
    blocks = []
    for path, text in files:
        lines = text.split("\n")
        per = []
        hits = 0
        for i, ln in enumerate(lines):
            nums = NUM_RE.findall(ln)
            # skip pure data-array lines (4+ numbers and almost nothing else)
            if len(nums) >= 4 and re.fullmatch(r'[\s0-9.eExXa-fA-F+\-,{}();]*', ln or ""):
                continue
            for tok in nums:
                try:
                    v = float(tok)
                except ValueError:
                    continue
                if lo <= v <= hi:
                    per.append("%d: %s   [%s]" % (i + 1, ln.strip()[:150], tok))
                    hits += 1
                    break
            if hits >= MAX_PER_FILE:
                per.append("    ... (capped)")
                break
        if per:
            blocks.append((path, hits, per))
    return blocks


def run_near(files, keyword):
    kw = re.compile(re.escape(keyword), re.I)
    blocks = []
    for path, text in files:
        lines = text.split("\n")
        per = []
        for i, ln in enumerate(lines):
            if kw.search(ln):
                nums = NUM_RE.findall(ln)
                if nums:
                    per.append("%d: %s   nums=%s" % (i + 1, ln.strip()[:140], ", ".join(nums[:8])))
            if len(per) >= MAX_PER_FILE:
                break
        if per:
            blocks.append((path, len(per), per))
    return blocks


def run_symbol(files, name, want_def):
    base = name.split("::")[-1]
    blocks = []
    for path, text in files:
        defs, calls = _analyze(text, base)
        if want_def:
            if defs:
                for body_open, dchar in defs[:3]:
                    body = _body_of(text, body_open)
                    ac = _arith(body)
                    head = [l[:96] for l in body.splitlines()[1:9]]
                    info = ["DEFINED at line %d   body=%d lines   calls-elsewhere=%d" %
                            (_lineno(text, dchar), body.count("\n"), calls),
                            "  math: " + " ".join("%s=%d" % (k, v) for k, v in ac.items()) +
                            ("   <- real formula" if sum(ac.values()) else "   <- WARNING: no math (stub/thunk?)"),
                            "  body head:"]
                    info += ["    " + h for h in head]
                    blocks.append((path, 1, info))
            elif calls:
                blocks.append((path, 0, ["only CALLED here (%d call site(s)); not defined in this file" % calls]))
        else:
            if calls:
                # show the call lines
                lines = text.split("\n")
                per = []
                for i, ln in enumerate(lines):
                    if base in ln and not ln.lstrip().startswith("//"):
                        if re.search(r'(?<![A-Za-z0-9_])' + re.escape(base) + r'\s*\(', ln):
                            per.append("%d: %s" % (i + 1, ln.strip()[:150]))
                    if len(per) >= MAX_PER_FILE:
                        break
                blocks.append((path, calls, per or ["(%d call(s) detected)" % calls]))
    return blocks


# ----------------------------------------------------------------- top-level scan
def run_body(files, name):
    """Dump the COMPLETE body of every definition of NAME (the exact formula)."""
    base = name.split("::")[-1]
    blocks = []
    CAP = 1500
    for path, text in files:
        defs, calls = _analyze(text, base)
        if defs:
            for body_open, dchar in defs[:2]:
                fstart = text.rfind('\n', 0, dchar) + 1
                body = _body_of(text, body_open)
                full = text[fstart:body_open] + body
                start_ln = _lineno(text, fstart)
                lines = full.splitlines()
                info = ["FULL BODY  (starts line %d, %d lines)" % (start_ln, len(lines))]
                for j, l in enumerate(lines[:CAP]):
                    info.append("%d| %s" % (start_ln + j, l[:200]))
                if len(lines) > CAP:
                    info.append("... (%d more lines -- copy the rest from the file if needed)"
                                % (len(lines) - CAP))
                blocks.append((path, 1, info))
        elif calls:
            blocks.append((path, 0, ["only CALLED here (%d call(s)); the body lives in another DLL's .c"
                                     % calls]))
    return blocks


# ----------------------------------------------------------------- closure crawler
# Crawl the call graph from one or more seed functions over the decompiled .c
# already in the folder: dump EVERY reachable body in one pass, then report what
# is NOT in the folder (so it can be decompiled separately) plus indirect / vtable
# call sites that a human has to resolve. Heuristic C parsing, tuned to Ghidra.
_C_CALL    = re.compile(r'(~?[A-Za-z_]\w*(?:<[^>\n]{0,120}>)?(?:::~?[A-Za-z_]\w*(?:<[^>\n]{0,120}>)?)*)\s*\(')
_C_INDIR   = re.compile(r'\(\s*\*\*?\s*\(\s*code\s*\*\*?\s*\)\s*\(([^()]*)\)\s*\)\s*\(')
_C_PTRCALL = re.compile(r'\(\s*\*\s*(p[A-Za-z]\w*|pcVar\d+|pfVar\d+)\s*\)\s*\(')
_C_OFF     = re.compile(r'\+\s*(0x[0-9a-fA-F]+)')
_C_VFT     = re.compile(r'([A-Za-z_][\w:]*)::vftable')
_C_RTTI    = re.compile(r'([A-Za-z_][\w:]*)::RTTI_Type_Descriptor')
_C_INTR    = re.compile(r'^(CONCAT|SUB|ZEXT|SEXT|CARRY|SBORROW|POPCOUNT)\d*$')
_NS_NOISE  = {"std", "boost", "stdext", "__gnu_cxx", "Concurrency", "__cxxabiv1"}
_LIBM      = {"pow", "exp", "log", "log10", "log2", "sqrt", "cbrt", "fabs", "sin", "cos",
              "tan", "asin", "acos", "atan", "atan2", "floor", "ceil", "round", "fmod",
              "sinh", "cosh", "tanh", "abs", "fmin", "fmax", "hypot", "erf", "expm1", "log1p"}
_FUNC_NOISE = {"memcpy", "memmove", "memset", "malloc", "free", "calloc", "realloc",
               "strlen", "strcmp", "strncmp", "strcpy", "memcmp", "wcslen", "operator",
               "operator_new", "operator_delete", "__RTDynamicCast", "__RTtypeid",
               "_CxxThrowException", "_invalid_parameter_noinfo_noreturn", "__std_terminate",
               "_Xlength_error", "_Xout_of_range", "swap", "move", "forward", "get",
               "reset", "release", "c_str", "compare", "substr", "rfind", "append",
               "assign", "length", "size", "capacity", "resize", "reserve", "push_back",
               "pop_back", "emplace_back", "begin", "end", "cbegin", "cend", "data",
               "empty", "clear", "insert", "erase", "count", "str"}
_TYPE_NOISE = {"basic_string", "basic_ostream", "basic_ostringstream", "basic_ios",
               "char_traits", "allocator", "vector", "map", "set", "unordered_map", "pair",
               "optional", "unique_ptr", "shared_ptr", "function", "EqualityPredicate",
               "initializer_list", "tuple", "ostream", "istream", "_Func_impl",
               "_Func_impl_no_alloc", "_Vector_base"}


def _simple(name):
    return name.split("::")[-1].split("<")[0]


def _mask_cc(text):
    """Blank out comments and string/char literals (preserve length & newlines)."""
    out = []; i = 0; n = len(text); st = None
    while i < n:
        c = text[i]; nx = text[i + 1] if i + 1 < n else ''
        if st is None:
            if c == '/' and nx == '/': st = '//'; out.append('  '); i += 2; continue
            if c == '/' and nx == '*': st = '/*'; out.append('  '); i += 2; continue
            if c == '"':  st = '"';  out.append(' '); i += 1; continue
            if c == "'":  st = "'";  out.append(' '); i += 1; continue
            out.append(c); i += 1; continue
        if st == '//':
            if c == '\n': st = None; out.append('\n'); i += 1; continue
            out.append(' '); i += 1; continue
        if st == '/*':
            if c == '*' and nx == '/': st = None; out.append('  '); i += 2; continue
            out.append('\n' if c == '\n' else ' '); i += 1; continue
        if st == '"':
            if c == '\\': out.append('  '); i += 2; continue
            if c == '"':  st = None; out.append(' '); i += 1; continue
            out.append('\n' if c == '\n' else ' '); i += 1; continue
        if st == "'":
            if c == '\\': out.append('  '); i += 2; continue
            if c == "'":  st = None; out.append(' '); i += 1; continue
            out.append('\n' if c == '\n' else ' '); i += 1; continue
    return ''.join(out)


def _is_call_noise(name):
    if name.startswith("FUN_"):
        return False
    if name.split("::")[0] in _NS_NOISE:
        return True
    s = _simple(name)
    if s in KEYWORDS or s in _LIBM or s in _FUNC_NOISE or s in _TYPE_NOISE:
        return True
    if _C_INTR.match(name) or _C_INTR.match(s):
        return True
    if PSEUDO.match(name):
        return True
    return False


def _callees_of(full_text):
    m = _mask_cc(full_text)
    named = []; seen = set()
    for mt in _C_CALL.finditer(m):
        nm = mt.group(1)
        if nm not in seen:
            seen.add(nm); named.append(nm)
    inds = []
    for mt in _C_INDIR.finditer(m):
        off = _C_OFF.search(mt.group(1)); inds.append("vtable+" + (off.group(1) if off else "?"))
    for mt in _C_PTRCALL.finditer(m):
        inds.append("via " + mt.group(1))
    hints = sorted(set(_C_VFT.findall(m)) | set(_C_RTTI.findall(m)))
    return named, inds, hints


def _find_def(name, files):
    """First .c that DEFINES NAME -> (path, full_text, start_line, multi_bool)."""
    base = _simple(name); found = []
    for path, text in files:
        if base not in text:
            continue
        defs, calls = _analyze(text, base)
        if defs:
            body_open, dchar = defs[0]
            fstart = text.rfind('\n', 0, dchar) + 1
            body = _body_of(text, body_open)
            full = text[fstart:body_open] + body
            found.append((path, full, _lineno(text, fstart)))
    if not found:
        return None
    p, f, l = found[0]
    return (p, f, l, len(found) > 1)


def run_closure(files, dll_files, seeds_csv, rel, max_funcs=800, max_depth=18, body_cap=1500):
    from collections import deque, defaultdict, Counter
    seeds = [s for s in re.split(r'[,\s]+', seeds_csv) if s]
    if not seeds:
        return [">>> CLOSURE: give a seed, e.g.  closure: getShiftedForwardForSwaption"]

    queue = deque((s, 0) for s in seeds); visited = set()
    collected = []; callers = defaultdict(set); missing = set()
    virtual = defaultdict(set); allhints = set(); skipped = Counter(); multi = set()

    while queue and len(collected) < max_funcs:
        name, depth = queue.popleft()
        base = _simple(name)
        if base in visited:
            continue
        visited.add(base)
        d = _find_def(name, files)
        if d is None:
            missing.add(name); continue
        path, full, start_ln, mlt = d
        if mlt:
            multi.add(base)
        collected.append((name, path, full, start_ln, depth))
        if depth >= max_depth:
            continue
        named, inds, hints = _callees_of(full)
        allhints |= set(hints)
        for off in inds:
            virtual[name].add(off)
        for c in named:
            if _simple(c) == base:
                continue
            if _is_call_noise(c):
                skipped[c] += 1; continue
            callers[c].add(name)
            if _simple(c) not in visited:
                queue.append((c, depth + 1))
    budget_hit = len(collected) >= max_funcs and len(queue) > 0

    out = []
    out.append(">>> CLOSURE from: %s" % ", ".join(seeds))
    out.append("    collected %d function bodies (depth<=%d)%s" % (
        len(collected), max_depth,
        "  ** cap %d hit, %d queued -- narrow seeds or raise cap" % (max_funcs, len(queue)) if budget_hit else ""))
    if multi:
        out.append("    note: %d simple name(s) defined in >1 place; first shown" % len(multi))

    out.append("")
    out.append("    ===== BODIES (%d) =====" % len(collected))
    for name, path, full, start_ln, depth in collected:
        disp = rel(path) if os.path.exists(path) else path
        lines = full.splitlines()
        out.append("    --- %s   [depth %d]   <%s> ---" % (_simple(name), depth, os.path.basename(disp)))
        out.append("    FULL BODY (starts line %d, %d lines)" % (start_ln, len(lines)))
        for j, l in enumerate(lines[:body_cap]):
            out.append("    %d| %s" % (start_ln + j, l[:200]))
        if len(lines) > body_cap:
            out.append("    ... (%d more lines)" % (len(lines) - body_cap))
        out.append("")

    out.append("    ===== (1) DECOMPILE NEEDED -- not in this folder; handle separately =====")
    dll_for = defaultdict(set); notfound = []
    pe_ok = True
    try:
        import pefile  # noqa
    except Exception:
        pe_ok = False
    for nm in sorted(missing):
        b = _simple(nm); exps = []
        if pe_ok and dll_files:
            for d in dll_files:
                try:
                    exp, imp = _pe_symbol_match(d, b)
                    if exp:
                        exps.append(os.path.basename(d))
                except Exception:
                    pass
        if exps:
            for e in exps:
                dll_for[e].add(nm)
        else:
            notfound.append(nm)
    if dll_for:
        out.append("    decompile these DLLs, drop the .c into this folder, then re-run the same closure:")
        for e in sorted(dll_for):
            out.append("      %s   (needed for: %s)" % (
                e, ", ".join(sorted(_simple(x) for x in dll_for[e]))[:90]))
            out.append("          run:  python gd.py --dll <path>\\%s --out-dir <out>" % e)
    if notfound:
        if not pe_ok:
            out.append("    (pefile not installed -> can't name the DLL; install pefile, or these are the")
            out.append("     names to locate yourself:)")
        else:
            out.append("    not in any .c here and not exported by a DLL in the folder")
            out.append("    (likely inlined, static/internal, or that DLL isn't in this folder):")
        for nm in notfound[:80]:
            out.append("      - %-44s  called by: %s" % (
                _simple(nm), ", ".join(sorted(_simple(x) for x in callers.get(nm, [])))[:50]))
    if not dll_for and not notfound:
        out.append("    none -- every callee resolved inside this folder.")

    out.append("")
    out.append("    ===== (2) VIRTUAL DISPATCH -- indirect vtable calls; resolve by hand =====")
    if virtual:
        for caller in sorted(virtual):
            out.append("      in %s :  %s" % (_simple(caller), ", ".join(sorted(virtual[caller]))))
        if allhints:
            out.append("    candidate concrete classes seen in the closure (::vftable / RTTI):")
            for c in sorted(allhints)[:60]:
                out.append("      - %s" % c)
    else:
        out.append("    none.")

    if skipped:
        out.append("")
        out.append("    ===== (3) skipped as noise (std / runtime / libm) =====")
        for nm, c in skipped.most_common(40):
            out.append("      %5d  %s" % (c, nm))
    return out


def scan(root, request, exts_override=None):
    root = os.path.expanduser(root)
    if not os.path.isdir(root):
        return "ERROR: not a folder: %s" % root

    directives, exts, includes, excludes = parse_request(request)
    if exts_override:
        exts = exts_override
    if not directives:
        directives = [("list", "")]

    need_pe = any(k in ("symbol", "need", "locate", "closure", "trace", "crawl", "all")
                  for k, _ in directives)
    dll_files = list(iter_files(root, PE_EXTS)) if need_pe else []

    paths = list(iter_files(root, exts))

    if includes or excludes:
        def _keep(p):
            b = os.path.basename(p)
            if includes and not any(fnmatch.fnmatch(b, g) for g in includes):
                return False
            return not any(fnmatch.fnmatch(b, g) for g in excludes)
        paths = [p for p in paths if _keep(p)]
        dll_files = [p for p in dll_files if _keep(p)]
    files = []
    bytype = {}
    garbled_files = []
    for p in paths:
        ext = os.path.splitext(p)[1].lower()
        bytype[ext] = bytype.get(ext, 0) + 1
        text = read_text(p)
        files.append((p, text))
        if ext in {".c", ".cpp", ".h", ".txt"} and text and garbled(text):
            garbled_files.append(p)

    rel = lambda p: os.path.relpath(p, root)
    out = []
    bar = "=" * 78
    out.append(bar)
    out.append("SCANNED: %s" % root)
    out.append("files: %d   (%s)" % (len(files),
               ", ".join("%s:%d" % (k or "<none>", v) for k, v in sorted(bytype.items()))))
    if need_pe:
        out.append("binaries for symbol lookup (.dll/.exe): %d" % len(dll_files))
    if includes or excludes:
        out.append("name filter:  include=%s  skip=%s"
                   % (" ".join(includes) or "*", " ".join(excludes) or "(none)"))
    if garbled_files:
        out.append("!! OCR-garbled (constants from these are UNTRUSTED): " +
                   ", ".join(rel(p) for p in garbled_files[:8]) +
                   (" ..." if len(garbled_files) > 8 else ""))
    out.append(bar)

    for kind, arg in directives:
        out.append("")
        if kind == "list":
            out.append(">>> FILES")
            for p in sorted(paths):
                out.append("   " + rel(p))
            continue

        if kind in ("closure", "trace", "crawl", "all"):
            for line in run_closure(files, dll_files, arg, rel):
                out.append(line)
            continue

        if kind in ("need", "locate"):
            out.append(">>> NEED / LOCATE: %s" % arg)
            for line in run_need(files, dll_files, arg):
                out.append("   " + line)
            continue

        if kind == "symbol":
            label = "SYMBOL — which DLL defines / imports %s" % arg
            blocks = run_symbol_table(dll_files, arg)
        elif kind in ("find", "re"):
            label = ("REGEX " if kind == "re" else "FIND ") + repr(arg)
            blocks = run_find(files, arg, regex=(kind == "re"))
        elif kind == "const":
            m = re.match(r'([-+0-9.eE]+)\s*(?:~\s*([-+0-9.eE]+))?', arg)
            if not m:
                out.append(">>> CONST %r  -- could not parse a number" % arg)
                continue
            value = float(m.group(1))
            tol = float(m.group(2)) if m.group(2) else 5e-3
            label = "CONST ~ %s  (rel tol %s)" % (value, tol)
            blocks = run_const(files, value, tol)
        elif kind == "near":
            label = "NEAR %r" % arg
            blocks = run_near(files, arg)
        elif kind == "body":
            label = "FULL BODY of %s" % arg
            blocks = run_body(files, arg)
        elif kind == "def":
            label = "DEFINITION of %s" % arg
            blocks = run_symbol(files, arg, want_def=True)
        elif kind == "calls":
            label = "CALL SITES of %s" % arg
            blocks = run_symbol(files, arg, want_def=False)
        else:
            continue

        out.append(">>> %s" % label)
        if not blocks:
            out.append("   (no matches)")
            continue
        total = sum(b[1] for b in blocks)
        out.append("   %d match(es) across %d file(s)" % (total, len(blocks)))
        for path, n, per in blocks:
            tag = " [OCR-garbled]" if path in garbled_files else ""
            disp = rel(path) if os.path.exists(path) else path
            out.append("   --- %s%s ---" % (disp, tag))
            for line in per:
                out.append("       " + line)
    out.append("")
    out.append(bar)
    out.append("Done. (Local only -- nothing left this machine.)")
    return "\n".join(out)


# ----------------------------------------------------------------- GUI
HELP_DEFAULT = """# Paste your request here, one directive per line. '#' = comment.
# A plain line with no prefix is just a text search. Examples:
#
#   closure: getVol            GET EVERYTHING IN ONE GO: crawl getVol + every function it
#                              calls (and what those call...) over the .c in this folder.
#                              Also lists which DLLs to decompile next + vtable calls to
#                              read by hand. Seeds can be comma-separated.
#
#   epsilonPut                 find this text anywhere
#   conservativeEpsilons
#   def: getImpliedSigma_CF    where is this function defined (shows its body head)
#   body: getVol               dump the FULL body of a function (the exact formula)
#   symbol: getVol             which .dll *defines* (exports) vs imports it (reads PE tables; needs pefile)
#   need: getVol               do I have it, or must I decompile another DLL? (one-line verdict; put the DLLs in the folder)
#   calls: getVol              where is getVol called
#   const: 0.0025              numbers ~ 0.0025  (add  ~ 1e-3  to set tolerance)
#   near: skew                 numbers on lines mentioning 'skew'
#   re: skew\\w*Shift           regex search
#   ext: .c .xml .xlsx         limit which file types are searched (whole request)
#   skip: *inlined* *raw*      skip files whose name matches (e.g. the huge inlined dumps)
#   files: *with_values.c      ONLY scan files whose name matches these patterns
#
epsilonPut
conservativeEpsilons
"""


def launch_gui():
    import threading
    import tkinter as tk
    from tkinter import ttk, filedialog, scrolledtext, messagebox

    root = tk.Tk()
    root.title("Decompile / Config Scanner  (offline)")
    root.geometry("1000x720")

    folder_var = tk.StringVar()
    ext_var = tk.StringVar()
    status_var = tk.StringVar(value="Ready.")

    top = ttk.Frame(root, padding=8)
    top.pack(fill="x")
    ttk.Label(top, text="Folder:").grid(row=0, column=0, sticky="w")
    fent = ttk.Entry(top, textvariable=folder_var)
    fent.grid(row=0, column=1, sticky="ew", padx=6)
    ttk.Button(top, text="Browse…",
               command=lambda: folder_var.set(filedialog.askdirectory() or folder_var.get())
               ).grid(row=0, column=2)
    ttk.Label(top, text="File types (optional, blank = all):").grid(row=1, column=0, sticky="w", pady=(6, 0))
    ttk.Entry(top, textvariable=ext_var).grid(row=1, column=1, sticky="ew", padx=6, pady=(6, 0))
    top.columnconfigure(1, weight=1)

    mid = ttk.Frame(root, padding=(8, 0))
    mid.pack(fill="x")
    ttk.Label(mid, text="Request:").pack(anchor="w")
    req = scrolledtext.ScrolledText(mid, height=10, wrap="word",
                                    font=("Consolas", 10))
    req.pack(fill="x")
    req.insert("1.0", HELP_DEFAULT)

    btns = ttk.Frame(root, padding=8)
    btns.pack(fill="x")
    scan_btn = ttk.Button(btns, text="  Scan  ")
    scan_btn.pack(side="left")
    ttk.Button(btns, text="Copy results",
               command=lambda: (root.clipboard_clear(),
                                root.clipboard_append(results.get("1.0", "end-1c")),
                                status_var.set("Results copied to clipboard."))
               ).pack(side="left", padx=6)
    ttk.Button(btns, text="Save results…", command=lambda: _save(results, status_var)
               ).pack(side="left")
    ttk.Button(btns, text="Clear request",
               command=lambda: (req.delete("1.0", "end"))).pack(side="left", padx=6)
    ttk.Label(btns, textvariable=status_var).pack(side="right")

    results = scrolledtext.ScrolledText(root, wrap="none", font=("Consolas", 10))
    results.pack(fill="both", expand=True, padx=8, pady=(0, 8))

    def _save(widget, status):
        path = filedialog.asksaveasfilename(defaultextension=".txt",
                                            filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if path:
            open(path, "w", encoding="utf-8").write(widget.get("1.0", "end-1c"))
            status.set("Saved: " + path)

    def worker(folder, exts, request):
        try:
            report = scan(folder, request, exts_override=exts)
        except Exception as e:
            report = "ERROR while scanning:\n%r" % e
        root.after(0, lambda: _done(report))

    def _done(report):
        results.delete("1.0", "end")
        results.insert("1.0", report)
        scan_btn.config(state="normal")
        first = report.splitlines()
        status_var.set(next((l for l in first if l.startswith("files:")), "Done."))

    def on_scan():
        folder = folder_var.get().strip()
        if not folder or not os.path.isdir(os.path.expanduser(folder)):
            messagebox.showwarning("Folder", "Pick a valid folder first.")
            return
        exts = None
        if ext_var.get().strip():
            exts = set(t if t.startswith(".") else "." + t for t in ext_var.get().split())
        request = req.get("1.0", "end-1c")
        scan_btn.config(state="disabled")
        status_var.set("Scanning…")
        threading.Thread(target=worker, args=(folder, exts, request), daemon=True).start()

    scan_btn.config(command=on_scan)
    root.mainloop()


# ----------------------------------------------------------------- entry point
def main(argv):
    if "--scan" in argv:
        i = argv.index("--scan")
        folder = argv[i + 1]
        request = ""
        if "--request" in argv:
            request = argv[argv.index("--request") + 1]
        elif "--request-file" in argv:
            request = open(argv[argv.index("--request-file") + 1], encoding="utf-8").read()
        print(scan(folder, request))
        return 0
    launch_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
