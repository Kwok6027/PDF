#!/usr/bin/env python3
"""
diag.py  --  quick diagnosis of the closure crawler on YOUR files. Finishes in
about a minute (it never runs the full closure). Tells us whether the fast index
is actually detecting your functions, whether the fallback is thrashing, and how
big the closure really is.

Usage:
    python diag.py "C:\\Users\\45293751\\Desktop\\Projects\\Pandora\\Pending"
    python diag.py "C:\\...\\Pending" getShiftedForwardForSwaption    (optional seed)

Send me everything it prints.
"""
import sys, os, glob, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import code_scan as cs

folder = sys.argv[1] if len(sys.argv) > 1 else "."
seed = sys.argv[2] if len(sys.argv) > 2 else "getShiftedForwardForSwaption"

exts = (".c", ".h", ".cpp")
paths = [p for p in glob.glob(os.path.join(folder, "**", "*"), recursive=True)
         if p.lower().endswith(exts)]
print("=" * 60)
print("folder        :", folder)
print("source files  :", len(paths))
if not paths:
    print("!! no .c/.h/.cpp files found here. Wrong folder?")
    sys.exit(0)
tot = sum(os.path.getsize(p) for p in paths)
print("total size    : %.1f MB" % (tot / 1e6))
big = sorted(((os.path.getsize(p), p) for p in paths), reverse=True)[:5]
print("largest files :")
for sz, p in big:
    print("    %7.1f MB  %s" % (sz / 1e6, os.path.basename(p)))

print("\nreading files ...")
t = time.time()
files = []
for p in paths:
    try:
        files.append((p, open(p, encoding="utf-8", errors="replace").read()))
    except Exception as e:
        print("  read FAIL:", os.path.basename(p), e)
print("read in %.1fs" % (time.time() - t))

# 1) masking speed (this runs once per file during indexing, and once per function during crawl)
print("\n[1] masking speed (sample of up to 3 largest files):")
t = time.time()
for sz, p in big[:3]:
    txt = dict(files).get(p, "")
    cs._mask_fast(txt)
print("    masked 3 files in %.1fs" % (time.time() - t))

# 2) index build -- THE KEY NUMBER
print("\n[2] building index (the fast path)...")
t = time.time()
idx = cs._index_functions(files)
dt = time.time() - t
ndef = sum(len(v) for v in idx.values())
print("    INDEX: %d distinct names, %d definitions, built in %.1fs" % (len(idx), ndef, dt))
if ndef < 50:
    print("    *** WARNING: very few functions indexed -- the detector is probably")
    print("    *** NOT recognising your function format. This is the likely cause.")
samp = list(idx.keys())[:25]
print("    sample names found:", samp)

# 3) quick capped closure from one seed -> resolution breakdown + rate
print("\n[3] quick closure from seed '%s' (capped at 400 to stay fast)..." % seed)
t = time.time()
lines = cs.run_closure(files, [], seed, lambda p: os.path.basename(p), max_funcs=400)
dt = time.time() - t
hdr = [l for l in lines if "collected" in l or "resolution:" in l
       or "COMPLETE" in l or "cap" in l or "fallback" in l.lower()][:6]
print("    ran in %.1fs" % dt)
for l in hdr:
    print("   ", l.strip())
ncol = sum(1 for l in lines if l.strip().startswith("--- "))
if ncol:
    print("    rate: %.1f functions/sec" % (ncol / max(dt, 0.001)))
    print("    -> at that rate, a 40,000-function closure would take ~%.0f min"
          % (40000 / max(ncol / max(dt, 0.001), 0.001) / 60))
print("=" * 60)
print("Send me everything above. The decisive numbers are [2] (functions indexed)")
print("and [3] (resolution: how many via index vs fallback, and the rate).")
