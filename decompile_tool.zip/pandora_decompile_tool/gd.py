#!/usr/bin/env python3
"""
gd.py  -- run this with your normal Python:  python gd.py

Decompiles a DLL (or EXE) with Ghidra headless, then extracts the .rdata data tables
and folds constants + tables into one self-contained .c.

Two ways to run:

  * SINGLE  -- pick one DLL (the interactive prompts, as before).
  * BATCH   -- point it at a FOLDER and it decompiles every DLL inside, one by one.

In both cases each DLL gets its OWN output subfolder named after it, and on success the
DLL is moved into that subfolder so a re-run never repeats it.

Interactive (GUI / console prompts):
    python gd.py

Command line (scriptable batch):
    python gd.py --dll-dir  C:\\dlls  --out-dir  C:\\out  [--ghidra C:\\ghidra_11.x]
    python gd.py --dll      C:\\x.dll --out-dir  C:\\out
Useful flags:
    --filter SUBSTR   only decompile functions whose name contains SUBSTR (faster)
    --no-move         leave the DLL where it is (default: move it into its output folder)
    --copy            copy the DLL into its output folder instead of moving
    --force           re-run even DLLs already marked done
    --dry-run         show the plan; create nothing, run nothing, move nothing
    --verbose / -v    stream the full Ghidra log instead of a progress bar

Needs: Ghidra + a JDK already installed (NOT pip-installable). No pip packages required
here (Tkinter is part of the standard library; if missing, it falls back to console prompts).
"""
import os, sys, subprocess, tempfile, glob, json, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
IS_WIN = (os.name == "nt")
HEADLESS = "analyzeHeadless.bat" if IS_WIN else "analyzeHeadless"
BIN_EXTS = {".dll", ".exe", ".ocx"}


def find_ghidra():
    """Best-effort auto-detect of a Ghidra install (the folder containing support/analyzeHeadless)."""
    for var in ("GHIDRA_INSTALL_DIR", "GHIDRA_HOME", "GHIDRA_DIR", "GHIDRA_ROOT"):
        p = os.environ.get(var)
        if p and os.path.isfile(os.path.join(p, "support", HEADLESS)):
            return p
    home = os.path.expanduser("~")
    roots = [home, os.path.join(home, "Desktop"), os.path.join(home, "Downloads"),
             os.path.join(home, "Documents"), os.path.join(home, "Tools"),
             "/opt", "/usr/share", "/usr/local", "/Applications",
             "C:\\", "C:\\Program Files", "C:\\Program Files (x86)", "C:\\Tools", "C:\\ghidra"]
    cands = []
    for r in roots:
        try:
            cands += glob.glob(os.path.join(r, "ghidra_*"))
            cands += glob.glob(os.path.join(r, "ghidra_*", "ghidra_*"))   # nested unzip
            cands += glob.glob(os.path.join(r, "ghidra*", "ghidra_*"))
        except Exception:
            pass
    for c in cands:
        if os.path.isfile(os.path.join(c, "support", HEADLESS)):
            return c
    return None


def get_inputs_gui(default_ghidra):
    import tkinter as tk
    from tkinter import filedialog, messagebox
    root = tk.Tk(); root.withdraw()
    batch = messagebox.askyesno(
        "Ghidra decompiler",
        "Decompile a whole FOLDER of DLLs (batch)?\n\n"
        "Yes = pick a folder; every DLL inside is decompiled, one by one.\n"
        "No  = pick a single DLL.")
    if batch:
        target = filedialog.askdirectory(title="Select the folder that contains the DLLs")
    else:
        target = filedialog.askopenfilename(
            title="Select the DLL to decompile",
            filetypes=[("Binaries", "*.dll *.exe"), ("All files", "*.*")])
    if not target:
        root.destroy(); return None
    ghidra = default_ghidra
    if not ghidra:
        messagebox.showinfo("Ghidra location",
                            "Ghidra was not auto-detected.\nChoose your Ghidra install "
                            "folder (the one that contains a 'support' folder).")
        ghidra = filedialog.askdirectory(title="Select your Ghidra install folder")
        if not ghidra:
            root.destroy(); return None
    messagebox.showinfo("Output folder",
                        "Choose the output ROOT folder.\n"
                        "A subfolder named after each DLL is created inside it.\n"
                        "Press Cancel to use this script's folder:\n" + HERE)
    out = filedialog.askdirectory(title="Output root folder (Cancel = this script's folder)")
    if not out:
        out = HERE
    root.destroy()
    return target, batch, ghidra, out


def get_inputs_console(default_ghidra):
    print("\n(Tkinter not available - using console prompts.)\n")
    ans = input("Batch mode? Decompile a whole FOLDER of DLLs? [y/N]: ").strip().lower()
    batch = ans.startswith("y")
    if batch:
        target = input("Full path to the FOLDER of DLLs: ").strip().strip('"')
    else:
        target = input("Full path to the DLL/EXE: ").strip().strip('"')
    if not target:
        return None
    ghidra = default_ghidra
    if ghidra:
        print("Auto-detected Ghidra at: %s" % ghidra)
        alt = input("Press Enter to use it, or type another Ghidra install folder: ").strip().strip('"')
        if alt:
            ghidra = alt
    else:
        ghidra = input("Ghidra install folder (contains 'support'): ").strip().strip('"')
        if not ghidra:
            return None
    out = input("Output ROOT folder (Enter = this script's folder): ").strip().strip('"')
    if not out:
        out = HERE
    return target, batch, ghidra, out


import threading, time, math

# ---------------------------------------------------------------------------
# clean progress bar (replaces Ghidra's wall of log lines)
# ---------------------------------------------------------------------------
try:
    "█".encode(sys.stdout.encoding or "utf-8")
    _FILL, _EMPTY = "█", "·"
except Exception:
    _FILL, _EMPTY = "#", "-"


class Bar:
    def __init__(self, width=28, enabled=True):
        self.width = width
        self.enabled = enabled

    def update(self, pct, label=""):
        if not self.enabled:
            return
        pct = max(0.0, min(100.0, float(pct)))
        filled = int(round(self.width * pct / 100.0))
        line = "\r[%s%s] %3d%%  %-26.26s" % (
            _FILL * filled, _EMPTY * (self.width - filled), int(pct), label)
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
        except Exception:
            pass

    def finish(self):
        if not self.enabled:
            return
        try:
            sys.stdout.write("\n")
            sys.stdout.flush()
        except Exception:
            pass


def run_with_bar(cmd, log_path, bar, lo, hi, label, markers=None, tau=45.0, verbose=False):
    """Run cmd. In verbose mode the output streams to the console as normal (no bar).
    Otherwise the output is captured to log_path and a single-line bar is animated
    from lo toward hi: it time-crawls within the band and snaps forward whenever a
    (substring, pct) marker is seen in the output. Returns the process return code."""
    if verbose:
        return subprocess.call(cmd)
    markers = markers or []
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            bufsize=1, universal_newlines=True, errors="replace")
    shared = {"pct": float(lo)}

    def _reader():
        try:
            with open(log_path, "w", encoding="utf-8", errors="replace") as lf:
                for line in proc.stdout:
                    lf.write(line)
                    for sub, p in markers:
                        if sub in line and p > shared["pct"]:
                            shared["pct"] = float(p)
        except Exception:
            pass

    th = threading.Thread(target=_reader, daemon=True)
    th.start()
    start = time.time()
    while proc.poll() is None:
        elapsed = time.time() - start
        crawl = lo + (hi - lo) * (1.0 - math.exp(-elapsed / tau)) * 0.9
        bar.update(min(max(shared["pct"], crawl), hi - 0.5), label)
        time.sleep(0.25)
    th.join(timeout=2.0)
    bar.update(hi, label)
    return proc.returncode


# ---------------------------------------------------------------------------
# batch helpers
# ---------------------------------------------------------------------------
def find_dlls(root, exts, exclude=None):
    """Recursively list binaries under root, skipping anything under `exclude`."""
    exclude = os.path.realpath(exclude) if exclude else None
    out = []
    for dp, _dirs, files in os.walk(root):
        rp = os.path.realpath(dp)
        if exclude and (rp == exclude or rp.startswith(exclude + os.sep)):
            continue
        for f in files:
            p = os.path.join(dp, f)
            if os.path.isfile(p) and os.path.splitext(f)[1].lower() in exts:
                out.append(p)
    return sorted(out)


def read_manifest(d):
    mp = os.path.join(d, "decompile_manifest.json")
    if os.path.isfile(mp):
        try:
            return json.load(open(mp, encoding="utf-8"))
        except Exception:
            return None
    return None


def resolve_outdir(out_root, name, dll):
    """Pick this dll's output subfolder and say what to do:
       'done' (already succeeded -> skip), 'retry' (re-run into it), 'fresh' (new)."""
    bn = os.path.basename(dll)
    base = os.path.join(out_root, name)
    cand = base
    i = 1
    while os.path.exists(cand):
        m = read_manifest(cand)
        same = bool(m) and os.path.basename(m.get("source", "")) == bn
        if same and m.get("success"):
            return cand, "done"
        if same and not m.get("success"):
            return cand, "retry"
        if not m:
            return cand, "retry"     # leftover folder, no record -> reuse
        i += 1                       # a different dll happens to share this stem
        cand = "%s_%d" % (base, i)
    return cand, "fresh"


def write_manifest(outdir, name, dll, ok, seconds, moved_to, main_out):
    manifest = {
        "name": name, "source": dll, "outdir": outdir,
        "success": bool(ok), "seconds": round(seconds, 1),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "moved_dll_to": moved_to, "main_output": main_out,
        "outputs": sorted(os.listdir(outdir)) if os.path.isdir(outdir) else [],
    }
    try:
        json.dump(manifest, open(os.path.join(outdir, "decompile_manifest.json"),
                                 "w", encoding="utf-8"), indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# the per-DLL pipeline (unchanged steps; now writes into a per-DLL folder)
# ---------------------------------------------------------------------------
def decompile_one(dll, ghidra, outdir, name_filter, verbose):
    """Full Ghidra + rdata + merge pipeline for ONE dll into outdir.
    Returns (ok, main_output_path_or_None). ok == a .decompiled.c was produced."""
    headless = os.path.join(ghidra, "support", HEADLESS)
    base = os.path.basename(dll)
    os.makedirs(outdir, exist_ok=True)
    ghidra_log = os.path.join(outdir, base + ".ghidra.log")
    proj_dir = tempfile.mkdtemp(prefix="ghidra_proj_")
    cmd = [headless, proj_dir, "tmpproj",
           "-import", dll,
           "-scriptPath", HERE,
           "-postScript", "GhidraPostExport.java", outdir]
    if name_filter:
        cmd.append(name_filter)
    cmd += ["-deleteProject", "-overwrite"]

    bar = Bar(enabled=not verbose)
    if verbose:
        print("  " + " ".join('"%s"' % c if " " in c else c for c in cmd) + "\n")
    else:
        print("  (Ghidra log -> %s)" % os.path.basename(ghidra_log))
    bar.update(2, "Starting Ghidra…")

    # 1) Ghidra: analyze + RTTI + C export + DAT_ dump  (band 3 -> 78)
    rc = run_with_bar(
        cmd, ghidra_log, bar, 3, 78, "Analyzing in Ghidra…",
        markers=[("recovering C++", 58), ("exporting full C", 68),
                 ("DAT_ entries", 75), ("[post] DONE", 78)],
        tau=60.0, verbose=verbose)
    if rc != 0:
        bar.finish()
        print("  Ghidra exited with code %d.  Log -> %s" % (rc, ghidra_log))
        return False, None

    cs = sorted(glob.glob(os.path.join(outdir, "*.decompiled.c")), key=os.path.getmtime)
    vs = sorted(glob.glob(os.path.join(outdir, "*.dat_constants.csv")), key=os.path.getmtime)
    if not cs and not vs:
        bar.finish()
        print("  Ghidra finished but produced no .decompiled.c / .csv.  Log -> %s" % ghidra_log)
        return False, None

    # 2) bulk .rdata table extraction  (band 78 -> 90)
    extractor = os.path.join(HERE, "extract_rdata_tables.py")
    idx = None
    if os.path.isfile(extractor) and vs:
        run_with_bar(
            [sys.executable, extractor, dll, vs[-1], "--out", outdir],
            os.path.join(outdir, base + ".rdata_extract.log"), bar, 78, 90,
            "Extracting .rdata tables…",
            markers=[("wrote raw", 82), ("flat f64", 84),
                     ("catalogued", 88), ("[rdata] DONE", 90)],
            tau=10.0, verbose=verbose)
        ix = sorted(glob.glob(os.path.join(outdir, "*.rdata_tables_index.csv")), key=os.path.getmtime)
        idx = ix[-1] if ix else None

    # 3) fold values into the C, table-aware  (band 90 -> 99)
    merger = os.path.join(HERE, "merge_dat_into_c.py")
    c_inline = None
    if cs and vs and os.path.isfile(merger):
        c_in, v_in = cs[-1], vs[-1]
        c_annot = c_in.replace(".decompiled.c", ".decompiled.with_values.c")
        if c_annot == c_in:
            c_annot = c_in + ".with_values.c"
        c_inline = c_in.replace(".decompiled.c", ".decompiled.with_values.inlined.c")
        if c_inline == c_in:
            c_inline = c_in + ".with_values.inlined.c"
        tbl = (["--tables", idx] if idx else [])
        embed = (["--dll", dll] if idx else [])   # makes the inlined file self-contained
        mlog = os.path.join(outdir, base + ".merge.log")
        run_with_bar([sys.executable, merger, c_in, v_in, c_annot] + tbl,
                     mlog, bar, 90, 94, "Folding values into C…", verbose=verbose)
        run_with_bar([sys.executable, merger, c_in, v_in, c_inline, "--inline"] + tbl + embed,
                     mlog, bar, 94, 99, "Embedding tables into C…", verbose=verbose)

    bar.update(100, "Done")
    bar.finish()
    ok = bool(cs)
    main_out = (c_inline if (c_inline and os.path.isfile(c_inline)) else (cs[-1] if cs else None))
    return ok, main_out


# ---------------------------------------------------------------------------
# batch driver
# ---------------------------------------------------------------------------
def process_all(dll_list, ghidra, out_root, name_filter, verbose,
                move=True, copy=False, dry=False, force=False):
    if not dry:
        os.makedirs(out_root, exist_ok=True)
    print("=" * 72)
    print("output root : %s" % out_root)
    print("to process  : %d binary(ies)" % len(dll_list))
    if dry:
        print("MODE        : DRY RUN -- nothing will be created, run, or moved")
    print("=" * 72)

    done = skipped = failed = 0
    failed_list = []
    n = len(dll_list)
    for i, dll in enumerate(dll_list, 1):
        name = os.path.splitext(os.path.basename(dll))[0]
        outdir, status = resolve_outdir(out_root, name, dll)
        rel = os.path.basename(dll)
        if status == "done" and not force:
            print("\n[%d/%d] %-38s already done -> %s  (skip)" % (i, n, rel, outdir))
            skipped += 1
            continue
        action = "copy" if copy else ("leave" if not move else "move")
        print("\n[%d/%d] %s  ->  %s" % (i, n, rel, outdir))
        if dry:
            print("        (dry run: would decompile, then %s the dll in)" % action)
            continue

        t0 = time.time()
        try:
            ok, main_out = decompile_one(dll, ghidra, outdir, name_filter, verbose)
        except Exception as e:
            ok, main_out = False, None
            print("        ERROR: %r" % e)
        dt = time.time() - t0

        moved_to = None
        if ok and move:
            try:
                dst = os.path.join(outdir, os.path.basename(dll))
                if copy:
                    shutil.copy2(dll, dst)
                else:
                    shutil.move(dll, dst)
                moved_to = dst
            except Exception as e:
                print("        (decompile ok but moving the dll failed: %r)" % e)
        write_manifest(outdir, name, dll, ok, dt, moved_to, main_out)

        if ok:
            done += 1
            tag = "  [dll moved in]" if (moved_to and not copy) else ("  [dll copied in]" if moved_to else "")
            print("        done in %.0fs%s" % (dt, tag))
            if main_out:
                print("        main output: %s" % os.path.basename(main_out))
        else:
            failed += 1
            failed_list.append(rel)
            print("        FAILED -- dll left in place to retry")

    print("\n" + "=" * 72)
    print("done: %d   skipped: %d   failed: %d" % (done, skipped, failed))
    for r in failed_list:
        print("   FAILED  %s" % r)
    if not dry:
        try:
            with open(os.path.join(out_root, "batch_decompile_summary.txt"),
                      "w", encoding="utf-8") as s:
                s.write("done %d  skipped %d  failed %d\n" % (done, skipped, failed))
                for r in failed_list:
                    s.write("FAILED %s\n" % r)
        except Exception:
            pass
    print("=" * 72)
    return 0 if failed == 0 else 1


def _val(argv, name):
    """--name VALUE  or  --name=VALUE"""
    for i, a in enumerate(argv):
        if a == name and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith(name + "="):
            return a.split("=", 1)[1]
    return None


def main():
    argv = sys.argv[1:]
    verbose = ("--verbose" in argv) or ("-v" in argv)
    name_filter = _val(argv, "--filter")
    dll_dir = _val(argv, "--dll-dir")
    out_dir = _val(argv, "--out-dir")
    ghidra = _val(argv, "--ghidra")
    dll_single = _val(argv, "--dll")
    no_move = "--no-move" in argv
    copy = "--copy" in argv
    dry = "--dry-run" in argv
    force = "--force" in argv

    if not ghidra:
        ghidra = find_ghidra()

    # ---- decide targets + output root (CLI if any path flag given, else interactive) ----
    cli = bool(dll_dir or dll_single or out_dir)
    if cli:
        if not out_dir:
            print("ERROR: --out-dir is required when using --dll-dir / --dll.")
            return 2
        if not (dll_dir or dll_single):
            print("ERROR: give --dll-dir <folder>  or  --dll <file>.")
            return 2
        if not ghidra:
            print("ERROR: Ghidra not found. Pass --ghidra <install folder>.")
            return 2
        out_root = os.path.realpath(os.path.expanduser(out_dir))
        if dll_dir:
            d = os.path.realpath(os.path.expanduser(dll_dir))
            if not os.path.isdir(d):
                print("ERROR: --dll-dir is not a folder: %s" % d)
                return 2
            dll_list = find_dlls(d, BIN_EXTS, exclude=out_root)
        else:
            f = os.path.realpath(os.path.expanduser(dll_single))
            if not os.path.isfile(f):
                print("ERROR: --dll not found: %s" % f)
                return 2
            dll_list = [f]
    else:
        try:
            import tkinter  # noqa
            picked = get_inputs_gui(ghidra)
        except Exception:
            picked = get_inputs_console(ghidra)
        if not picked:
            print("Cancelled.")
            return 1
        target, batch, ghidra, out = picked
        out_root = os.path.realpath(os.path.expanduser(out))
        if batch:
            d = os.path.realpath(os.path.expanduser(target))
            if not os.path.isdir(d):
                print("ERROR: not a folder: %s" % d)
                return 2
            dll_list = find_dlls(d, BIN_EXTS, exclude=out_root)
        else:
            dll_list = [os.path.realpath(os.path.expanduser(target))]

    # ---- one-time validation ----
    problems = []
    if not ghidra or not os.path.isfile(os.path.join(ghidra, "support", HEADLESS)):
        problems.append("analyzeHeadless not found under Ghidra folder: %s" % ghidra)
    if not os.path.isfile(os.path.join(HERE, "GhidraPostExport.java")):
        problems.append("Missing helper next to launcher: GhidraPostExport.java")
    if not dll_list:
        problems.append("No DLLs/EXEs found to process.")
    if problems:
        print("\n".join("ERROR: " + p for p in problems))
        return 2

    return process_all(dll_list, ghidra, out_root, name_filter, verbose,
                        move=not no_move, copy=copy, dry=dry, force=force)


if __name__ == "__main__":
    sys.exit(main())
