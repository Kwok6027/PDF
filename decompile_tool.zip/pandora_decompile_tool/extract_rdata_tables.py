#!/usr/bin/env python3
"""
extract_rdata_tables.py  -- capture the BULK read-only data tables (.rdata) that
the decompile pipeline's per-DAT_ dump does NOT capture.

Why this exists
---------------
GhidraPostExport.java records only ONE qword (one double) per DAT_ label. When the
code does DAT_start[i], Ghidra labels only DAT_start, so everything past the first
element of every array is lost. For a binary whose .rdata is mostly large numeric
tables, that means almost all of the data never gets dumped.

This script reads the whole .rdata section straight from the binary (pefile) and:
  1) writes the entire section as raw bytes              -> <name>.rdata.bin
  2) (if numpy is present) the whole section as f64       -> <name>.rdata.f64.npy
  3) segments .rdata into tables using the DAT_ addresses from the pipeline's
     <name>.dat_constants.csv -- each table spans from its DAT_ address to the
     next labelled address -- classifies each (double / pointer / string / mixed),
     and writes:
        <name>.rdata_tables_index.csv   catalogue of every span (always complete)
        <name>.rdata_tables/            one file per substantial table

Needs:  pefile   (pip install pefile)        -- to parse the PE
        numpy    (optional)                  -- nicer stats + the .npy flat dump;
                                                without it the standard library is used.

Usage:
    python extract_rdata_tables.py <binary.dll> [dat_constants.csv]
                                   [--out DIR] [--file-min N] [--no-npy]
    # the csv is auto-found next to the binary / in the out dir / cwd if omitted
"""
import os, sys, csv, re, math, glob, array, struct

TOKEN = re.compile(r'_?DAT_([0-9A-Fa-f]+)')

# section characteristic flags
SCN_READ  = 0x40000000
SCN_WRITE = 0x80000000
SCN_EXEC  = 0x20000000

# qwords within [image_base, image_base + PTR_SPAN] are treated as likely pointers
PTR_SPAN = 0x10000000


# ----------------------------------------------------------------------
# pure helpers (no pefile / no I/O) -- unit-testable on synthetic bytes
# ----------------------------------------------------------------------
def decode_f64_le(buf):
    """bytes -> array('d') of little-endian doubles (trailing <8 bytes ignored)."""
    n = len(buf) // 8
    a = array.array('d')
    if n:
        a.frombytes(buf[:n * 8])
        if sys.byteorder == 'big':
            a.byteswap()
    return a


def decode_u64_le(buf):
    """bytes -> array('Q') of little-endian uint64 (trailing <8 bytes ignored)."""
    n = len(buf) // 8
    a = array.array('Q')
    if n:
        a.frombytes(buf[:n * 8])
        if sys.byteorder == 'big':
            a.byteswap()
    return a


def double_stats(ds):
    finite = [d for d in ds if math.isfinite(d)]
    if not finite:
        return {"n": len(ds), "finite": 0, "min": "", "max": "", "mean": ""}
    return {"n": len(ds), "finite": len(finite),
            "min": min(finite), "max": max(finite),
            "mean": sum(finite) / len(finite)}


def classify_span(buf, image_base, ptr_span=PTR_SPAN, sample=4096):
    """Return (kind, stats). kind in {double, ptr, string, mixed, tiny}."""
    n = len(buf) // 8
    if n == 0:
        return "tiny", {"n_bytes": len(buf)}

    qs = decode_u64_le(buf)
    ds = decode_f64_le(buf)
    m = min(n, sample)
    qsamp = qs[:m]

    # 1) pointer / vtable table: most qwords land in the image's address range
    ptr_hits = sum(1 for q in qsamp if image_base <= q <= image_base + ptr_span)
    if ptr_hits / m > 0.5:
        return "ptr", {"n_qwords": n, "ptr_frac": round(ptr_hits / m, 3)}

    # 2) string blob: bytes are overwhelmingly printable ASCII (+ tab/nl/cr/null)
    bs = buf[:sample * 8]
    if bs:
        printable = sum(1 for b in bs if b in (9, 10, 13, 0) or 32 <= b <= 126)
        if printable / len(bs) > 0.90:
            return "string", {"n_bytes": len(buf)}

    # 3) numeric table: doubles are finite and in a sane magnitude band
    ok = 0
    for d in ds[:m]:
        if math.isfinite(d) and (d == 0.0 or 1e-300 < abs(d) < 1e300):
            ok += 1
    if ok / m > 0.80:
        return "double", double_stats(ds)

    return "mixed", {"n_qwords": n}


def segment(boundary_vas, sec_va, sec_end):
    """Partition [sec_va, sec_end) at every boundary VA. sec_va is always a boundary,
    so the whole section is covered. Returns sorted [(start_va, length_bytes), ...]."""
    bs = sorted(set([sec_va] + [v for v in boundary_vas if sec_va < v < sec_end]))
    spans = []
    for i, v in enumerate(bs):
        end = bs[i + 1] if i + 1 < len(bs) else sec_end
        if end > v:
            spans.append((v, end - v))
    return spans


# ----------------------------------------------------------------------
# I/O helpers
# ----------------------------------------------------------------------
def load_dat_vas(csv_path):
    """Read DAT_ addresses from the pipeline's csv. Returns {va: read_only_bool}."""
    out = {}
    with open(csv_path, "r", newline="") as f:
        for row in csv.DictReader(f):
            name = (row.get("name") or "").strip()
            ro = (row.get("read_only", "") or "").strip().lower() == "yes"
            m = TOKEN.search(name)
            va = None
            if m:
                va = int(m.group(1), 16)
            else:
                a = (row.get("address") or "").strip()
                try:
                    va = int(a, 16)
                except ValueError:
                    va = None
            if va is not None:
                out[va] = ro
    return out


def pick_data_section(pe):
    """Prefer .rdata; else the largest read-only, non-exec section."""
    ro = [s for s in pe.sections
          if (s.Characteristics & SCN_READ)
          and not (s.Characteristics & SCN_WRITE)
          and not (s.Characteristics & SCN_EXEC)]
    for s in ro:
        if s.Name.rstrip(b"\x00") == b".rdata":
            return s, ro
    if ro:
        return max(ro, key=lambda s: s.Misc_VirtualSize), ro
    return None, ro


def fmt_preview(kind, buf, image_base, k=6):
    if kind == "double":
        ds = decode_f64_le(buf)[:k]
        return " ".join("%.6g" % d for d in ds)
    if kind == "ptr":
        qs = decode_u64_le(buf)[:k]
        return " ".join("0x%x" % q for q in qs)
    if kind == "string":
        txt = buf[:48].decode("latin-1")
        return "".join(c if 32 <= ord(c) <= 126 else "." for c in txt)
    qs = decode_u64_le(buf)[:k]
    return " ".join("0x%x" % q for q in qs)


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", s)


def write_table_file(tdir, base, tname, kind, buf, image_base, want_npy):
    """Write a per-table file for substantial spans. Returns the filename or None."""
    stem = "%s__%s" % (base, tname)
    if kind == "double":
        ds = decode_f64_le(buf)
        if want_npy:
            try:
                import numpy as np
                fn = stem + ".f64.npy"
                np.save(os.path.join(tdir, fn), np.frombuffer(buf[:len(ds) * 8], dtype="<f8"))
                return fn
            except Exception:
                pass
        fn = stem + ".f64.csv"
        with open(os.path.join(tdir, fn), "w") as f:
            f.write("\n".join(repr(d) for d in ds))
        return fn
    if kind == "ptr":
        qs = decode_u64_le(buf)
        fn = stem + ".ptrs.txt"
        with open(os.path.join(tdir, fn), "w") as f:
            f.write("\n".join("0x%x" % q for q in qs))
        return fn
    if kind == "string":
        fn = stem + ".str.txt"
        with open(os.path.join(tdir, fn), "wb") as f:
            f.write(buf)
        return fn
    # mixed / unknown -> raw slice, let the user reinterpret
    fn = stem + ".bin"
    with open(os.path.join(tdir, fn), "wb") as f:
        f.write(buf)
    return fn


# ----------------------------------------------------------------------
def values_for_index(dll_path, index_path):
    """FULL contents of every multi-element table, read straight from the binary.
    Returns {va_int: {'kind','n','values'|'text'|'raw','min','max'}} for n>=2 spans.
    Needs pefile. Used by merge_dat_into_c.py --dll to embed the tables inline."""
    import pefile
    pe = pefile.PE(dll_path, fast_load=True)
    image_base = pe.OPTIONAL_HEADER.ImageBase
    sec, _ = pick_data_section(pe)
    if sec is None:
        return {}
    raw = sec.get_data()
    vsize = sec.Misc_VirtualSize or len(raw)
    data = raw[:min(vsize, len(raw))]
    sec_va = image_base + sec.VirtualAddress
    out = {}
    with open(index_path, "r", newline="") as f:
        for row in csv.DictReader(f):
            try:
                va = int((row.get("start_va") or "").strip(), 16)
            except ValueError:
                continue
            try:
                nb = int(row.get("n_bytes") or "0")
            except ValueError:
                nb = 0
            off = va - sec_va
            if off < 0 or off >= len(data) or nb <= 0:
                continue
            buf = data[off:off + nb]
            kind = (row.get("kind") or "").strip()
            entry = {"kind": kind,
                     "min": (row.get("min") or "").strip(),
                     "max": (row.get("max") or "").strip()}
            if kind == "double":
                vals = list(decode_f64_le(buf))
                if len(vals) < 2:
                    continue
                entry["n"] = len(vals); entry["values"] = vals
            elif kind == "ptr":
                vals = list(decode_u64_le(buf))
                if len(vals) < 2:
                    continue
                entry["n"] = len(vals); entry["values"] = vals
            elif kind == "string":
                if len(buf) < 2:
                    continue
                entry["n"] = len(buf); entry["bytes"] = buf
            else:
                if len(buf) < 2:
                    continue
                entry["n"] = len(buf); entry["raw"] = buf
            out[va] = entry
    return out


def auto_find_csv(binary, outdir):
    base = os.path.basename(binary)
    for d in (os.path.dirname(os.path.abspath(binary)), outdir, os.getcwd()):
        if not d:
            continue
        exact = os.path.join(d, base + ".dat_constants.csv")
        if os.path.isfile(exact):
            return exact
        hits = sorted(glob.glob(os.path.join(d, "*.dat_constants.csv")))
        if hits:
            return hits[0]
    return None


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    flags = [a for a in argv if a.startswith("--")]
    if not args:
        print(__doc__)
        return 2
    binary = args[0]
    csv_path = args[1] if len(args) >= 2 else None

    outdir = os.getcwd()
    for f in flags:
        if f.startswith("--out="):
            outdir = f.split("=", 1)[1]
    if "--out" in argv:
        i = argv.index("--out")
        if i + 1 < len(argv):
            outdir = argv[i + 1]
    file_min = 8
    if "--file-min" in argv:
        i = argv.index("--file-min")
        if i + 1 < len(argv):
            file_min = int(argv[i + 1])
    want_npy = "--no-npy" not in argv

    if not os.path.isfile(binary):
        print("ERROR: binary not found: %s" % binary)
        return 2
    if not os.path.isdir(outdir):
        os.makedirs(outdir, exist_ok=True)

    try:
        import pefile
    except ImportError:
        print("ERROR: this step needs pefile.  Install it and re-run:")
        print("    pip install pefile")
        return 2

    pe = pefile.PE(binary, fast_load=True)
    image_base = pe.OPTIONAL_HEADER.ImageBase
    sec, ro_secs = pick_data_section(pe)
    if sec is None:
        print("ERROR: no read-only data section found.")
        return 2

    sec_name = sec.Name.rstrip(b"\x00").decode("latin-1")
    raw = sec.get_data()
    vsize = sec.Misc_VirtualSize or len(raw)
    data = raw[:min(vsize, len(raw))]
    sec_va = image_base + sec.VirtualAddress
    sec_end = sec_va + len(data)

    base = os.path.basename(binary)
    print("[rdata] image base 0x%x" % image_base)
    print("[rdata] section %s: %d bytes, VA 0x%x .. 0x%x" % (sec_name, len(data), sec_va, sec_end))
    others = [s.Name.rstrip(b'\x00').decode('latin-1') for s in ro_secs
              if s.Name.rstrip(b'\x00') != sec.Name.rstrip(b'\x00')]
    if others:
        print("[rdata] (other read-only sections present but not segmented: %s)" % ", ".join(others))

    # 1) raw dump -- guarantees nothing is lost
    raw_path = os.path.join(outdir, base + ".rdata.bin")
    with open(raw_path, "wb") as f:
        f.write(data)
    print("[rdata] wrote raw bytes        -> %s" % os.path.basename(raw_path))

    # 2) flat f64 dump (numpy)
    if want_npy:
        try:
            import numpy as np
            n = len(data) // 8
            flat = os.path.join(outdir, base + ".rdata.f64.npy")
            np.save(flat, np.frombuffer(data[:n * 8], dtype="<f8"))
            print("[rdata] wrote flat f64 (%d)   -> %s" % (n, os.path.basename(flat)))
        except ImportError:
            print("[rdata] (numpy not installed; skipping .npy flat dump -- the .bin has every byte)")

    # 3) segment using DAT_ boundaries
    if csv_path is None:
        csv_path = auto_find_csv(binary, outdir)
    dat_vas = {}
    if csv_path and os.path.isfile(csv_path):
        dat_vas = load_dat_vas(csv_path)
        print("[rdata] using DAT_ boundaries from %s (%d labels)" % (os.path.basename(csv_path), len(dat_vas)))
    else:
        print("[rdata] no dat_constants.csv found -- segmentation skipped (raw + flat dump still written).")

    in_sec = {va for va in dat_vas if sec_va <= va < sec_end}
    spans = segment(in_sec, sec_va, sec_end)

    tdir = os.path.join(outdir, base + ".rdata_tables")
    os.makedirs(tdir, exist_ok=True)
    index_path = os.path.join(outdir, base + ".rdata_tables_index.csv")

    counts = {}
    written = 0
    with open(index_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["name", "start_va", "n_bytes", "n_doubles", "read_only",
                    "kind", "min", "max", "mean", "file", "preview"])
        for (start, length) in spans:
            off = start - sec_va
            buf = data[off:off + length]
            kind, stats = classify_span(buf, image_base)
            counts[kind] = counts.get(kind, 0) + 1
            n_doubles = length // 8
            tname = ("DAT_%x" % start) if start in in_sec else ("rdata_%x" % start)
            ro = "yes" if dat_vas.get(start, False) else ("" if start not in in_sec else "no")
            fn = ""
            if n_doubles >= file_min:
                fn = write_table_file(tdir, base, safe_name(tname), kind, buf, image_base, want_npy) or ""
                if fn:
                    written += 1
            w.writerow([tname, "0x%x" % start, length, n_doubles, ro, kind,
                        stats.get("min", ""), stats.get("max", ""), stats.get("mean", ""),
                        fn, fmt_preview(kind, buf, image_base)])

    print("[rdata] catalogued %d spans (%s)" %
          (len(spans), ", ".join("%s:%d" % (k, v) for k, v in sorted(counts.items()))))
    print("[rdata] index               -> %s" % os.path.basename(index_path))
    print("[rdata] wrote %d per-table files (n_doubles >= %d) in %s/"
          % (written, file_min, os.path.basename(tdir)))
    print("[rdata] DONE")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
