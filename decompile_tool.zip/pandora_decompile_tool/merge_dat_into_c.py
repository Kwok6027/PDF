#!/usr/bin/env python3
"""
merge_dat_into_c.py  -- fold the DAT_ constant values (from the .csv the pipeline
produced) back into the decompiled .c so the DAT_180... references become readable.

Usage:
    python merge_dat_into_c.py                       # auto-find *.decompiled.c + *.dat_constants.csv in this folder
    python merge_dat_into_c.py code.c consts.csv     # explicit files
    python merge_dat_into_c.py code.c consts.csv out.c
    add  --inline   to also replace read-only double constants in place (e.g. DAT_x -> (0.5))

What it does (non-destructive by default):
    * prepends a comment table of every DAT_ value at the top of the file
    * appends a trailing /* DAT: ... */ note to every line that references a DAT_,
      showing the value (double / pointer / int) or marking it <runtime> if it is a
      writable global with no static value
    * with --inline, additionally substitutes the literal value for read-only doubles

No pip packages needed (standard library only).
"""
import sys, os, csv, re, math, glob

TOKEN = re.compile(r'_?DAT_([0-9A-Fa-f]+)')
IMAGE_BASE = 0x180000000        # PandoraMMMDynamics.dll preferred base (adjust if different)
PTR_SPAN = 0x10000000           # treat qwords within [base, base+span] as likely pointers


def load_csv(path):
    table = {}
    with open(path, "r", newline="") as f:
        for row in csv.DictReader(f):
            name = (row.get("name") or "").strip()
            m = TOKEN.search(name)
            key = m.group(1).lower() if m else name.lower()
            table[key] = row
    return table


def key_to_va(key):
    """A DAT_ hex key like '180012340' -> int VA; non-hex names -> None."""
    try:
        return int(key, 16)
    except (ValueError, TypeError):
        return None


def load_tables(path):
    """Read <name>.rdata_tables_index.csv -> {va_int: {n_doubles, kind, min, max, preview, file}}.
    This is what lets us show array bases AS ARRAYS instead of as a single scalar."""
    out = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, "r", newline="") as f:
        for row in csv.DictReader(f):
            try:
                va = int((row.get("start_va") or "").strip(), 16)
            except ValueError:
                continue
            try:
                nd = int(row.get("n_doubles") or "0")
            except ValueError:
                nd = 0
            out[va] = {
                "n_doubles": nd,
                "kind": (row.get("kind") or "").strip(),
                "min": (row.get("min") or "").strip(),
                "max": (row.get("max") or "").strip(),
                "preview": (row.get("preview") or "").strip(),
                "file": (row.get("file") or "").strip(),
            }
    return out


def classify(row):
    """Return (kind, display) where kind in {runtime, ptr, double, int, unknown}."""
    ro = (row.get("read_only", "") or "").strip().lower() == "yes"
    if not ro:
        return "runtime", None
    q = None
    try:
        q = int((row.get("qword_hex", "") or "").strip() or "x", 16)
    except Exception:
        q = None
    d = None
    try:
        d = float((row.get("double_LE", "") or "").strip())
    except Exception:
        d = None
    if q is not None and IMAGE_BASE <= q <= IMAGE_BASE + PTR_SPAN:
        return "ptr", "0x%x" % q
    if d is not None:
        if d == 0.0:
            return "double", "0.0"
        if math.isfinite(d) and 1e-300 < abs(d) < 1e300:
            # tidy formatting
            s = repr(d)
            return "double", s
    if q is not None:
        return "int", "0x%x" % q
    return "unknown", None


def value_note(row, tbl=None):
    nm = (row.get("name") or "DAT").strip()
    # If this address is a real multi-element table, describe it AS A TABLE.
    if tbl and tbl.get("n_doubles", 0) >= 2:
        n = tbl["n_doubles"]
        short = {"double": "f64", "ptr": "ptr", "string": "str",
                 "mixed": "raw", "tiny": "raw"}.get(tbl.get("kind", ""), "raw")
        prev = tbl.get("preview", "")
        rng = ""
        if tbl.get("kind") == "double" and tbl.get("min", "") != "":
            try:
                rng = " [%.6g..%.6g]" % (float(tbl["min"]), float(tbl["max"]))
            except ValueError:
                rng = ""
        unit = "doubles" if short == "f64" else ("pointers" if short == "ptr" else "bytes")
        return "%s=%s[%d %s] {%s}%s" % (nm, short, n, unit, prev, rng)
    kind, disp = classify(row)
    if kind == "runtime":
        return "%s=<runtime>" % nm
    if kind == "double":
        return "%s=%s" % (nm, disp)
    if kind == "ptr":
        return "%s=ptr %s" % (nm, disp)
    if kind == "int":
        return "%s=%s" % (nm, disp)
    return "%s=?" % nm


def _wrap(values, per_line, fmt):
    rows = []
    for i in range(0, len(values), per_line):
        rows.append("  " + ", ".join(fmt(v) for v in values[i:i + per_line]) + ",")
    return rows


def _c_escape_byte(b):
    """Escape one byte for a C string. Non-printables become octal \\NNN (3 digits,
    unambiguous in C) so nothing odd ends up in the file to confuse the editor."""
    if b == 9:
        return "\\t"
    if b == 10:
        return "\\n"
    if b == 13:
        return "\\r"
    if b == 34:
        return "\\\""
    if b == 92:
        return "\\\\"
    if 32 <= b <= 126:
        return chr(b)
    return "\\%03o" % b


def format_tables_block(full_tables, names, max_elems=None):
    """Render the FULL contents of every data table as an embedded C block.
    full_tables: {va_int: {'kind','n','values'|'text'|'raw','min','max'}}
    names:       {va_int: 'DAT_xxxx'}"""
    if not full_tables:
        return "", 0
    out = ["/* ============================================================",
           " * DATA TABLES  --  full contents of every .rdata table, embedded here",
           " * The decompiled code addresses these by BYTE offset, e.g.",
           " *     *(double *)(DAT_x + (long)i * 8)   ==   DAT_x[i]",
           " * (so this section replaces the separate rdata_tables_index.csv + rdata_tables/ folder)",
           " * ============================================================ */",
           ""]
    total = 0
    for va in sorted(full_tables):
        e = full_tables[va]
        nm = names.get(va, "DAT_%x" % va)
        kind, n = e.get("kind", ""), e.get("n", 0)
        if kind == "double":
            vals = e.get("values", [])
            shown = vals if (max_elems is None or n <= max_elems) else vals[:max_elems]
            total += len(shown)
            rng = ""
            if e.get("min", "") != "":
                try:
                    rng = "  range [%.6g .. %.6g]" % (float(e["min"]), float(e["max"]))
                except ValueError:
                    rng = ""
            cap = ("  (first %d of %d; full data in rdata_tables/)" % (len(shown), n)) if len(shown) < n else ""
            out.append("/* %s : %d doubles%s%s */" % (nm, n, rng, cap))
            out.append("static const double %s[%d] = {" % (nm, len(shown)))
            out += _wrap(shown, 8, lambda d: repr(d))
            out += ["};", ""]
        elif kind == "ptr":
            vals = e.get("values", [])
            shown = vals if (max_elems is None or n <= max_elems) else vals[:max_elems]
            total += len(shown)
            out.append("/* %s : %d pointers (likely vtable / RTTI) */" % (nm, n))
            out.append("static const unsigned long long %s[%d] = {" % (nm, len(shown)))
            out += _wrap(shown, 6, lambda q: "0x%xULL" % q)
            out += ["};", ""]
        elif kind == "string":
            raw = e.get("bytes")
            if raw is None:
                raw = e.get("text", "").encode("latin-1", "replace")
            total += len(raw)
            out.append("/* %s : %d bytes (text) */" % (nm, n))
            out.append("static const char %s[] =" % nm)
            pieces, cur = [], ""
            for b in raw:                      # keep each source line short (~78 chars)
                tok = _c_escape_byte(b)
                if len(cur) + len(tok) > 78:
                    pieces.append(cur)
                    cur = ""
                cur += tok
            pieces.append(cur)
            for i, p in enumerate(pieces):
                out.append('  "%s"%s' % (p, ";" if i == len(pieces) - 1 else ""))
            out.append("")
        else:
            out.append("/* %s : %d bytes (mixed/raw) -- see %s in rdata_tables/ */" % (nm, n, nm))
            out.append("")
    return "\n".join(out), total


def merge(c_path, csv_path, out_path, inline=False, tables=None,
          full_tables=None, max_table_elems=None):
    table = load_csv(csv_path)
    tables = tables or {}
    with open(c_path, "r") as f:
        lines = f.read().split("\n")

    def tbl_for(key):
        va = key_to_va(key)
        return tables.get(va) if va is not None else None

    def is_array(key):
        t = tbl_for(key)
        return bool(t and t.get("n_doubles", 0) >= 2)

    out = []
    # ---- header reference table ----
    out.append("/* ============================================================")
    out.append(" * DAT_ constants merged from %s" % os.path.basename(csv_path))
    if tables:
        out.append(" * arrays are shown AS ARRAYS (e.g. f64[256 doubles]) from the .rdata table catalogue")
    out.append(" * read-only entries have a real value; <runtime> = writable global (no static value)")
    out.append(" * format:  NAME = value   |   NAME = f64[N doubles] {first few} [min..max]")
    out.append(" * ------------------------------------------------------------")
    for key in sorted(table):
        out.append(" *   " + value_note(table[key], tbl_for(key)))
    out.append(" * ============================================================ */")
    out.append("")

    # ---- full data tables embedded inline (this is what replaces #3 + #6) ----
    n_embedded = 0
    if full_tables:
        block, n_embedded = format_tables_block(full_tables, {}, max_elems=max_table_elems)
        if block:
            out.append(block)
            out.append("")

    # ---- per-line annotation (and optional inline substitution) ----
    n_lines_annotated = 0
    n_subst = 0
    for line in lines:
        hexes = TOKEN.findall(line)
        new = line
        if inline and hexes:
            def _repl(m):
                key = m.group(1).lower()
                if is_array(key):          # never inline an array base as a scalar
                    return m.group(0)
                row = table.get(key)
                if row:
                    kind, disp = classify(row)
                    if kind == "double":
                        return "(" + disp + ")"
                return m.group(0)
            before = new
            new = TOKEN.sub(_repl, new)
            if new != before:
                n_subst += 1
        if hexes:
            notes, seen = [], set()
            for h in hexes:
                k = h.lower()
                if k in seen:
                    continue
                seen.add(k)
                row = table.get(k)
                notes.append(value_note(row, tbl_for(k)) if row else ("DAT_%s=?" % h))
            new = new.rstrip() + "   /* DAT: " + "  ".join(notes) + " */"
            n_lines_annotated += 1
        out.append(new)

    with open(out_path, "w") as f:
        f.write("\n".join(out))
    n_tables = sum(1 for k in table if is_array(k))
    return len(table), n_lines_annotated, n_subst, n_tables, n_embedded


def _auto_find():
    folder = os.path.dirname(os.path.abspath(__file__))
    c = sorted(glob.glob(os.path.join(folder, "*.decompiled.c"))) or \
        sorted(glob.glob(os.path.join(os.getcwd(), "*.decompiled.c")))
    v = sorted(glob.glob(os.path.join(folder, "*.dat_constants.csv"))) or \
        sorted(glob.glob(os.path.join(os.getcwd(), "*.dat_constants.csv")))
    return (c[0] if c else None), (v[0] if v else None)


def main(argv):
    inline = "--inline" in argv
    tables_path = None
    dll_path = None
    max_elems = None
    skip = set()
    for i, a in enumerate(argv):
        if a == "--tables" and i + 1 < len(argv):
            tables_path = argv[i + 1]; skip.add(i); skip.add(i + 1)
        elif a.startswith("--tables="):
            tables_path = a.split("=", 1)[1]; skip.add(i)
        elif a == "--dll" and i + 1 < len(argv):
            dll_path = argv[i + 1]; skip.add(i); skip.add(i + 1)
        elif a.startswith("--dll="):
            dll_path = a.split("=", 1)[1]; skip.add(i)
        elif a == "--max-table-elems" and i + 1 < len(argv):
            try:
                max_elems = int(argv[i + 1])
            except ValueError:
                max_elems = None
            skip.add(i); skip.add(i + 1)
        elif a.startswith("--max-table-elems="):
            try:
                max_elems = int(a.split("=", 1)[1])
            except ValueError:
                max_elems = None
            skip.add(i)
    args = [a for i, a in enumerate(argv) if i not in skip and not a.startswith("--")]
    if len(args) >= 2:
        c_path, csv_path = args[0], args[1]
        out_path = args[2] if len(args) >= 3 else None
    else:
        c_path, csv_path = _auto_find()
        out_path = None
        if not c_path or not csv_path:
            print("Could not auto-find the files. Pass them explicitly:")
            print("  python merge_dat_into_c.py <decompiled.c> <dat_constants.csv> [out.c]")
            print("                             [--inline] [--tables index.csv] [--dll the.dll] [--max-table-elems N]")
            return 2
    if out_path is None:
        out_path = c_path.replace(".decompiled.c", ".decompiled.with_values.c")
        if out_path == c_path:
            out_path = c_path + ".with_values.c"
    for p in (c_path, csv_path):
        if not os.path.isfile(p):
            print("ERROR: not found: %s" % p)
            return 2

    tables = load_tables(tables_path) if tables_path else {}

    # --dll + --tables: read the FULL table contents straight from the binary and
    # embed them, so the output file is self-contained (absorbs #3 and #6).
    full_tables = None
    if dll_path and tables_path:
        if not os.path.isfile(dll_path):
            print("WARNING: --dll not found (%s); embedding skipped, using previews only." % dll_path)
        else:
            try:
                import extract_rdata_tables as X
                full_tables = X.values_for_index(dll_path, tables_path)
            except ImportError as e:
                print("WARNING: could not embed full tables (%s). Install pefile (pip install pefile)" % e)
                print("         and keep extract_rdata_tables.py next to this script. Using previews only.")
            except Exception as e:
                print("WARNING: embedding full tables failed (%s); using previews only." % e)

    n, na, ns, nt, ne = merge(c_path, csv_path, out_path, inline=inline, tables=tables,
                              full_tables=full_tables, max_table_elems=max_elems)
    extra = ""
    if tables:
        extra += "; %d arrays as tables" % nt
    if inline:
        extra += "; inlined %d lines" % ns
    if full_tables:
        extra += "; embedded %d table values" % ne
    print("merged %d DAT_ values; annotated %d lines%s" % (n, na, extra))
    print("wrote: %s" % out_path)
    try:
        mb = os.path.getsize(out_path) / 1e6
        if mb >= 8:
            print("NOTE: this file is %.1f MB. If that's unwieldy, re-run with e.g. --max-table-elems 2000" % mb)
            print("      to cap each embedded table (the full values stay in the rdata_tables/ folder)." )
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
